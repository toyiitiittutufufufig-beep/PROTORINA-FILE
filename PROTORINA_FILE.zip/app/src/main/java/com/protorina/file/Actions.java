package com.protorina.file;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.content.FileProvider;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.EncryptionMethod;

/** File operations that need a dialog and/or a background thread. */
public class Actions {
    public interface Work {
        void run() throws Exception;
    }

    public static void work(final Activity a, String msg, final Work w, final Runnable done) {
        LinearLayout row = new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(a, 24);
        row.setPadding(p, p, p, p);
        row.addView(new ProgressBar(a), new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36)));
        TextView t = Ui.text(a, msg, 15, T.tx, false);
        t.setPadding(Ui.dp(a, 16), 0, 0, 0);
        row.addView(t);
        final AlertDialog d = Ui.dlg(a).setView(row).setCancelable(false).create();
        d.show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String err = null;
                try {
                    w.run();
                } catch (Throwable e) {
                    err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                }
                final String fe = err;
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        d.dismiss();
                        if (fe != null) Ui.toastLong(a, fe);
                        if (done != null) done.run();
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------ simple dialogs

    public static void newFolder(final Activity a, final File dir, final Runnable done) {
        Ui.prompt(a, "New folder", "Folder name", "", name -> {
            if (name.length() == 0) return;
            File f = new File(dir, name);
            if (f.exists() || !f.mkdirs()) Ui.toast(a, "Couldn't create the folder");
            done.run();
        });
    }

    public static void newFile(final Activity a, final File dir, final Runnable done) {
        Ui.prompt(a, "New file", "File name", "", name -> {
            if (name.length() == 0) return;
            File f = new File(dir, name);
            try {
                if (f.exists() || !f.createNewFile()) Ui.toast(a, "Couldn't create the file");
            } catch (Exception e) {
                Ui.toast(a, "Couldn't create the file");
            }
            done.run();
        });
    }

    public static void rename(final Activity a, final File f, final Runnable done) {
        Ui.prompt(a, "Rename", "New name", f.getName(), name -> {
            if (name.length() == 0 || name.equals(f.getName())) return;
            File to = new File(f.getParentFile(), name);
            if (to.exists()) Ui.toast(a, "That name already exists");
            else if (!f.renameTo(to)) Ui.toast(a, "Couldn't rename");
            done.run();
        });
    }

    public static void info(Activity a, File f) {
        String s = "Path: " + f.getAbsolutePath()
                + "\nType: " + (f.isDirectory() ? "Folder" : Fs.label(f))
                + "\nSize: " + (f.isDirectory() ? "-" : Fs.human(f.length()))
                + "\nModified: " + new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date(f.lastModified()))
                + "\nPermissions: " + (f.canRead() ? "r" : "-") + (f.canWrite() ? "w" : "-") + (f.canExecute() ? "x" : "-");
        TextView t = Ui.text(a, s, 14, T.tx, false);
        t.setTextIsSelectable(true);
        Ui.dlg(a).setTitle(f.getName()).setView(Ui.box(a, t)).setPositiveButton("Close", null).show();
    }

    public static void openWith(Activity a, File f, boolean share) {
        try {
            Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f);
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(Fs.ext(f));
            if (mime == null) mime = "*/*";
            Intent i = new Intent(share ? Intent.ACTION_SEND : Intent.ACTION_VIEW);
            if (share) {
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, uri);
            } else {
                i.setDataAndType(uri, mime);
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(i, share ? "Share" : "Open with"));
        } catch (Exception e) {
            Ui.toastLong(a, "No app can open this file");
        }
    }

    public static void copyText(Context c, String label, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
        Ui.toast(c, "Copied");
    }

    // ------------------------------------------------------------ zip

    public static void compress(final Activity a, final List<File> files, final File dir, final Runnable done) {
        String def = files.size() == 1 ? files.get(0).getName() : "archive";
        final EditText name = Ui.field(a, "Archive name", def, false);
        final EditText pw = Ui.field(a, "Password (optional)", "", true);
        Ui.dlg(a).setTitle("Compress to .zip").setView(Ui.box(a, name, pw))
                .setPositiveButton("Compress", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.length() == 0) n = "archive";
                    if (!n.toLowerCase(Locale.ROOT).endsWith(".zip")) n += ".zip";
                    final File out = Fs.unique(dir, n);
                    final String pass = pw.getText().toString();
                    work(a, "Compressing…", () -> {
                        ZipFile zf = pass.length() > 0 ? new ZipFile(out, pass.toCharArray()) : new ZipFile(out);
                        ZipParameters zp = new ZipParameters();
                        if (pass.length() > 0) {
                            zp.setEncryptFiles(true);
                            zp.setEncryptionMethod(EncryptionMethod.AES);
                            zp.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
                        }
                        for (File f : files) {
                            if (f.isDirectory()) zf.addFolder(f, zp);
                            else zf.addFile(f, zp);
                        }
                    }, done);
                }).setNegativeButton("Cancel", null).show();
    }

    public static void extract(final Activity a, final File zip, final Runnable done) {
        boolean enc = false;
        try {
            enc = new ZipFile(zip).isEncrypted();
        } catch (Exception e) {
            Ui.toastLong(a, "Can't read this archive: " + e.getMessage());
            return;
        }
        if (!enc) {
            doExtract(a, zip, null, done);
            return;
        }
        final EditText pw = Ui.field(a, "Password", "", true);
        Ui.dlg(a).setTitle("This archive is protected").setView(Ui.box(a, pw))
                .setPositiveButton("Extract", (d, w) -> doExtract(a, zip, pw.getText().toString(), done))
                .setNegativeButton("Cancel", null).show();
    }

    private static void doExtract(final Activity a, final File zip, final String pass, final Runnable done) {
        String base = zip.getName();
        int i = base.lastIndexOf('.');
        if (i > 0) base = base.substring(0, i);
        final File dest = Fs.unique(zip.getParentFile(), base);
        work(a, "Extracting…", () -> {
            ZipFile zf = new ZipFile(zip);
            if (pass != null) zf.setPassword(pass.toCharArray());
            zf.extractAll(dest.getAbsolutePath());
        }, done);
    }

    // ------------------------------------------------------------ crypto

    public static void encrypt(final Activity a, final File f, final Runnable done) {
        final EditText p1 = Ui.field(a, "Password", "", true);
        final EditText p2 = Ui.field(a, "Repeat password", "", true);
        Ui.dlg(a).setTitle("Encrypt " + f.getName()).setView(Ui.box(a, p1, p2))
                .setPositiveButton("Encrypt", (d, w) -> {
                    final String pw = p1.getText().toString();
                    if (pw.length() < 4) { Ui.toast(a, "Use at least 4 characters"); return; }
                    if (!pw.equals(p2.getText().toString())) { Ui.toast(a, "Passwords don't match"); return; }
                    final File out = Fs.unique(f.getParentFile(), f.getName() + ".pfe");
                    work(a, "Encrypting…", () -> Crypto.encrypt(f, out, pw.toCharArray()), done);
                }).setNegativeButton("Cancel", null).show();
    }

    public static void decrypt(final Activity a, final File f, final Runnable done) {
        final EditText pw = Ui.field(a, "Password", "", true);
        Ui.dlg(a).setTitle("Decrypt " + f.getName()).setView(Ui.box(a, pw))
                .setPositiveButton("Decrypt", (d, w) -> {
                    String n = f.getName();
                    n = n.toLowerCase(Locale.ROOT).endsWith(".pfe") ? n.substring(0, n.length() - 4) : n + ".dec";
                    final File out = Fs.unique(f.getParentFile(), n);
                    final String pass = pw.getText().toString();
                    work(a, "Decrypting…", () -> {
                        try {
                            Crypto.decrypt(f, out, pass.toCharArray());
                        } catch (Exception e) {
                            out.delete();
                            throw e;
                        }
                    }, done);
                }).setNegativeButton("Cancel", null).show();
    }

    public static void hash(final Activity a, final File f) {
        final String[] res = new String[3];
        work(a, "Calculating…", () -> {
            res[0] = Crypto.hash(f, "MD5");
            res[1] = Crypto.hash(f, "SHA-1");
            res[2] = Crypto.hash(f, "SHA-256");
        }, () -> {
            if (res[2] == null) return;
            String s = "MD5\n" + res[0] + "\n\nSHA-1\n" + res[1] + "\n\nSHA-256\n" + res[2];
            TextView t = Ui.mono(a, s, 12, T.tx);
            t.setTextIsSelectable(true);
            Ui.dlg(a).setTitle(f.getName()).setView(Ui.box(a, t))
                    .setPositiveButton("Copy SHA-256", (d, w) -> copyText(a, "SHA-256", res[2]))
                    .setNegativeButton("Close", null).show();
        });
    }

    public static void base64(final Activity a) {
        final EditText in = new EditText(a);
        in.setHint("Text");
        in.setMinLines(4);
        in.setGravity(Gravity.TOP);
        Ui.dlg(a).setTitle("Base64").setView(Ui.box(a, in))
                .setPositiveButton("Encode", (d, w) -> {
                    try {
                        showResult(a, "Encoded", Base64.encodeToString(in.getText().toString().getBytes("UTF-8"), Base64.NO_WRAP));
                    } catch (Exception e) {
                        Ui.toast(a, "Failed");
                    }
                })
                .setNeutralButton("Decode", (d, w) -> {
                    try {
                        showResult(a, "Decoded", new String(Base64.decode(in.getText().toString().trim(), Base64.DEFAULT), "UTF-8"));
                    } catch (Exception e) {
                        Ui.toast(a, "That isn't valid Base64");
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    private static void showResult(final Activity a, String title, final String s) {
        TextView t = Ui.mono(a, s, 13, T.tx);
        t.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(a);
        sv.addView(t);
        Ui.dlg(a).setTitle(title).setView(Ui.box(a, sv))
                .setPositiveButton("Copy", (d, w) -> copyText(a, title, s))
                .setNegativeButton("Close", null).show();
    }

    // ------------------------------------------------------------ search

    public static void findInFiles(final MainActivity a) {
        final EditText q = Ui.field(a, "Text to find", "", false);
        Ui.dlg(a).setTitle("Find in files").setView(Ui.box(a, q))
                .setPositiveButton("Choose folder", (d, w) -> {
                    final String query = q.getText().toString();
                    if (query.length() == 0) return;
                    Pick.show(a, null, 1, "Search in…", dir -> runSearch(a, dir, query));
                }).setNegativeButton("Cancel", null).show();
    }

    private static void runSearch(final MainActivity a, final File dir, final String query) {
        final List<String> hits = new ArrayList<String>();
        final List<File> files = new ArrayList<File>();
        work(a, "Searching…", () -> scan(dir, query.toLowerCase(Locale.ROOT), hits, files), () -> {
            if (hits.isEmpty()) {
                Ui.toast(a, "No matches");
                return;
            }
            ScrollView sv = new ScrollView(a);
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            sv.addView(col);
            final AlertDialog[] dlg = new AlertDialog[1];
            for (int i = 0; i < hits.size(); i++) {
                final File f = files.get(i);
                TextView t = Ui.mono(a, hits.get(i), 12, T.tx);
                t.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
                t.setOnClickListener(v -> {
                    dlg[0].dismiss();
                    a.openInEditor(f);
                });
                col.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            dlg[0] = Ui.dlg(a).setTitle(hits.size() + " matches" + (hits.size() >= 200 ? " (first 200)" : ""))
                    .setView(Ui.box(a, sv)).setNegativeButton("Close", null).create();
            dlg[0].show();
        });
    }

    private static void scan(File dir, String q, List<String> hits, List<File> files) throws Exception {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File f : kids) {
            if (hits.size() >= 200) return;
            if (f.isDirectory()) {
                scan(f, q, hits, files);
            } else if (f.length() < 5L * 1024 * 1024 && Fs.isText(f)) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                try {
                    String line;
                    int n = 0;
                    while ((line = br.readLine()) != null && hits.size() < 200) {
                        n++;
                        if (line.toLowerCase(Locale.ROOT).contains(q)) {
                            String s = line.trim();
                            if (s.length() > 90) s = s.substring(0, 90);
                            hits.add(f.getName() + ":" + n + "  " + s);
                            files.add(f);
                        }
                    }
                } finally {
                    br.close();
                }
            }
        }
    }
}
