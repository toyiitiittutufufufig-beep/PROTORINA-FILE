package com.protorina.file;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import net.dongliu.apk.parser.ApkFile;
import net.dongliu.apk.parser.bean.ApkMeta;
import net.dongliu.apk.parser.bean.ApkSigner;
import net.dongliu.apk.parser.bean.CertificateMeta;
import net.dongliu.apk.parser.bean.UseFeature;

import java.io.File;
import java.util.List;

public class ApkInfo {

    public static void show(final Activity a, final File apk) {
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 16);
        root.setPadding(p, p, p, p);

        TextView loading = Ui.text(a, "Reading APK…", 14, T.mu, false);
        loading.setGravity(Gravity.CENTER);
        root.addView(loading);

        ScrollView sv = new ScrollView(a);
        sv.addView(root);

        final android.app.AlertDialog dlg = Ui.dlg(a)
                .setTitle(apk.getName())
                .setView(sv)
                .setPositiveButton("Close", null)
                .setNegativeButton("Open with", (d, w) -> Actions.openWith(a, apk, false))
                .create();
        dlg.show();

        new Thread(() -> {
            String err = null;
            ApkMeta meta = null;
            byte[] iconBytes = null;
            String sigSha256 = null, sigSha1 = null, sigMd5 = null;
            try {
                ApkFile apkFile = new ApkFile(apk);
                meta = apkFile.getApkMeta();
                try { iconBytes = apkFile.getIconFile().getData(); } catch (Exception ignored) { }
                List<ApkSigner> signers = apkFile.getApkSingers();
                if (signers != null && !signers.isEmpty()) {
                    List<CertificateMeta> certs = signers.get(0).getCertificateMetas();
                    if (certs != null && !certs.isEmpty()) {
                        CertificateMeta cert = certs.get(0);
                        sigMd5 = cert.getMd5();
                        sigSha1 = cert.getSha1();
                        sigSha256 = cert.getSha256();
                    }
                }
                apkFile.close();
            } catch (Throwable t) {
                err = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            }
            final ApkMeta fm = meta;
            final byte[] fi = iconBytes;
            final String fSha256 = sigSha256, fSha1 = sigSha1, fMd5 = sigMd5;
            final String fe = err;
            a.runOnUiThread(() -> {
                root.removeAllViews();
                if (fe != null) {
                    TextView e = Ui.text(a, "Error: " + fe, 14, T.tx, false);
                    e.setTextIsSelectable(true);
                    root.addView(e);
                    return;
                }

                LinearLayout head = new LinearLayout(a);
                head.setGravity(Gravity.CENTER_VERTICAL);
                head.setPadding(0, 0, 0, Ui.dp(a, 12));
                if (fi != null && fi.length > 0) {
                    Bitmap bmp = BitmapFactory.decodeByteArray(fi, 0, fi.length);
                    if (bmp != null) {
                        ImageView iv = new ImageView(a);
                        iv.setImageBitmap(bmp);
                        head.addView(iv, new LinearLayout.LayoutParams(Ui.dp(a, 64), Ui.dp(a, 64)));
                    }
                }
                LinearLayout hcol = new LinearLayout(a);
                hcol.setOrientation(LinearLayout.VERTICAL);
                hcol.setPadding(Ui.dp(a, 12), 0, 0, 0);
                TextView title = Ui.text(a, fm.getLabel() == null ? "-" : fm.getLabel(), 17, T.tx, true);
                TextView pkg = Ui.mono(a, fm.getPackageName() == null ? "-" : fm.getPackageName(), 12, T.mu);
                hcol.addView(title);
                hcol.addView(pkg);
                head.addView(hcol);
                root.addView(head);

                addRow(root, "Version name", fm.getVersionName());
                addRow(root, "Version code", String.valueOf(fm.getVersionCode()));
                addRow(root, "Min SDK", String.valueOf(fm.getMinSdkVersion()));
                addRow(root, "Target SDK", String.valueOf(fm.getTargetSdkVersion()));
                addRow(root, "Max SDK", fm.getMaxSdkVersion() == null ? "-" : fm.getMaxSdkVersion());
                addRow(root, "APK size", Fs.human(apk.length()));
                addRow(root, "Install location", fm.getInstallLocation());

                List<String> perms = fm.getUsesPermissions();
                if (perms != null && !perms.isEmpty()) {
                    addSection(root, "Permissions (" + perms.size() + ")");
                    for (String perm : perms) addMono(root, perm);
                }

                List<UseFeature> feats = fm.getUsesFeatures();
                if (feats != null && !feats.isEmpty()) {
                    addSection(root, "Features (" + feats.size() + ")");
                    for (UseFeature f : feats) addMono(root, f.getName() + (f.getRequired() ? "  [required]" : ""));
                }

                addSection(root, "Signature");
                if (fSha256 != null) {
                    addRow(root, "MD5", fMd5);
                    addRow(root, "SHA-1", fSha1);
                    addRow(root, "SHA-256", fSha256);
                } else {
                    addMono(root, "Not signed");
                }
            });
        }).start();
    }

    private static void addSection(LinearLayout root, String title) {
        TextView t = Ui.text(root.getContext(), title, 14, T.ac, true);
        t.setPadding(0, Ui.dp(root.getContext(), 14), 0, Ui.dp(root.getContext(), 4));
        root.addView(t);
    }

    private static void addRow(LinearLayout root, String key, String value) {
        if (value == null) value = "-";
        LinearLayout row = new LinearLayout(root.getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, Ui.dp(root.getContext(), 4), 0, Ui.dp(root.getContext(), 4));
        TextView k = Ui.text(root.getContext(), key, 13, T.mu, false);
        k.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = Ui.mono(root.getContext(), value, 12, T.tx);
        v.setTextIsSelectable(true);
        row.addView(k);
        row.addView(v);
        root.addView(row);
    }

    private static void addMono(LinearLayout root, String text) {
        TextView t = Ui.mono(root.getContext(), text, 11, T.tx);
        t.setTextIsSelectable(true);
        t.setPadding(0, Ui.dp(root.getContext(), 2), 0, Ui.dp(root.getContext(), 2));
        root.addView(t);
    }
}