package com.protorina.file;

import android.app.Activity;
import android.widget.EditText;

import com.android.apksig.ApkSigner;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Collections;

public class ApkSign {

    public static void sign(final Activity a, final File apk, final Runnable done) {
        final EditText path = Ui.field(a, "Keystore path (.jks)", "", false);
        final EditText pass = Ui.field(a, "Keystore password", "", true);
        final EditText alias = Ui.field(a, "Key alias", "", false);
        final EditText keyPass = Ui.field(a, "Key password (optional)", "", true);

        Ui.dlg(a)
                .setTitle("Sign " + apk.getName())
                .setView(Ui.box(a, path, pass, alias, keyPass))
                .setPositiveButton("Sign", (d, w) -> {
                    final String ksPath = path.getText().toString().trim();
                    final String ksPass = pass.getText().toString();
                    final String al = alias.getText().toString().trim();
                    final String kPass = keyPass.getText().toString();

                    if (ksPath.length() == 0 || al.length() == 0) {
                        Ui.toast(a, "Keystore path and alias are required");
                        return;
                    }

                    File ksFile = new File(ksPath);
                    if (!ksFile.exists()) {
                        Ui.toast(a, "Keystore file not found");
                        return;
                    }

                    String name = apk.getName();
                    if (name.toLowerCase().endsWith(".apk")) name = name.substring(0, name.length() - 4);
                    final File out = Fs.unique(apk.getParentFile(), name + "-signed.apk");

                    Actions.work(a, "Signing…", () -> {
                        char[] ksPw = ksPass.toCharArray();
                        char[] keyPw = kPass.length() > 0 ? kPass.toCharArray() : ksPw;

                        KeyStore ks = KeyStore.getInstance("JKS");
                        FileInputStream fis = new FileInputStream(ksFile);
                        try {
                            ks.load(fis, ksPw);
                        } finally {
                            fis.close();
                        }

                        PrivateKey key = (PrivateKey) ks.getKey(al, keyPw);
                        if (key == null) throw new Exception("Key alias not found or wrong password");

                        X509Certificate cert = (X509Certificate) ks.getCertificate(al);
                        if (cert == null) throw new Exception("Certificate not found for alias");

                        ApkSigner.SignerConfig signerConfig = new ApkSigner.SignerConfig.Builder(
                                al, key, Collections.singletonList(cert)).build();

                        ApkSigner signer = new ApkSigner.Builder(Collections.singletonList(signerConfig))
                                .setInputApk(apk)
                                .setOutputApk(out)
                                .setV1SigningEnabled(true)
                                .setV2SigningEnabled(true)
                                .setV3SigningEnabled(true)
                                .build();

                        signer.sign();
                    }, () -> {
                        Ui.toast(a, "Signed: " + out.getName());
                        if (done != null) done.run();
                    });
                })
                .setNeutralButton("Pick keystore", (d, w) -> Pick.show(a, null, 0, "Pick keystore", f -> {
                    path.setText(f.getAbsolutePath());
                }))
                .setNegativeButton("Cancel", null)
                .show();
    }
}