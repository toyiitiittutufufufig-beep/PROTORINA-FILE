package com.protorina.file;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

import com.github.junrar.Archive;
import com.github.junrar.rarfile.FileHeader;

/**
 * Universal archive handler: extract ZIP / 7z / TAR / TAR.GZ / GZ / RAR / XZ.
 * Compress: ZIP (via zip4j in Actions) and TAR.GZ.
 */
public class Archives {

    /** Detects format from file extension. */
    public static String format(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) return "targz";
        if (n.endsWith(".tar.xz") || n.endsWith(".txz")) return "tarxz";
        if (n.endsWith(".tar.bz2") || n.endsWith(".tbz2")) return "tarbz2";
        if (n.endsWith(".tar")) return "tar";
        if (n.endsWith(".7z")) return "7z";
        if (n.endsWith(".rar")) return "rar";
        if (n.endsWith(".gz")) return "gz";
        if (n.endsWith(".xz")) return "xz";
        if (n.endsWith(".bz2")) return "bz2";
        if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".apk") || n.endsWith(".xapk")) return "zip";
        return "unknown";
    }

    public static boolean isArchive(File f) {
        String fmt = format(f);
        return !fmt.equals("unknown");
    }

    /**
     * Universal extractor. Picks the right reader based on extension.
     */
    public static void extract(File archive, File destDir) throws Exception {
        String fmt = format(archive);
        if (!destDir.exists() && !destDir.mkdirs()) {
            throw new IOException("Can't create destination folder");
        }
        switch (fmt) {
            case "zip":    extractZip(archive, destDir, null); break;
            case "7z":     extract7z(archive, destDir); break;
            case "tar":    extractTar(new FileInputStream(archive), destDir); break;
            case "targz":  extractTarGz(archive, destDir); break;
            case "tarxz":  extractTarXz(archive, destDir); break;
            case "gz":     extractGz(archive, destDir); break;
            case "xz":     extractXz(archive, destDir); break;
            case "rar":    extractRar(archive, destDir); break;
            default:
                // fallback to zip4j in case it's a zip with unusual extension
                extractZip(archive, destDir, null);
        }
    }

    public static void extract(File archive, File destDir, String password) throws Exception {
        String fmt = format(archive);
        if (fmt.equals("zip")) {
            extractZip(archive, destDir, password);
        } else {
            extract(archive, destDir);
        }
    }

    // ---------------------------------------------------------------- ZIP

    private static void extractZip(File archive, File destDir, String password) throws Exception {
        net.lingala.zip4j.ZipFile zf = new net.lingala.zip4j.ZipFile(archive);
        if (password != null) zf.setPassword(password.toCharArray());
        zf.extractAll(destDir.getAbsolutePath());
    }

    // ---------------------------------------------------------------- 7z

    private static void extract7z(File archive, File destDir) throws Exception {
        SevenZFile z = new SevenZFile(archive);
        try {
            SevenZArchiveEntry e;
            byte[] buf = new byte[65536];
            while ((e = z.getNextEntry()) != null) {
                File out = safeChild(destDir, e.getName());
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
                try {
                    int n;
                    while ((n = z.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    os.close();
                }
            }
        } finally {
            z.close();
        }
    }

    // ---------------------------------------------------------------- TAR

    private static void extractTar(InputStream rawIn, File destDir) throws Exception {
        TarArchiveInputStream tin = new TarArchiveInputStream(new BufferedInputStream(rawIn));
        try {
            TarArchiveEntry e;
            byte[] buf = new byte[65536];
            while ((e = tin.getNextTarEntry()) != null) {
                File out = safeChild(destDir, e.getName());
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
                try {
                    int n;
                    while ((n = tin.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    os.close();
                }
            }
        } finally {
            tin.close();
        }
    }

    private static void extractTarGz(File archive, File destDir) throws Exception {
        FileInputStream fis = new FileInputStream(archive);
        GzipCompressorInputStream gz = new GzipCompressorInputStream(new BufferedInputStream(fis));
        extractTar(gz, destDir);
    }

    private static void extractTarXz(File archive, File destDir) throws Exception {
        FileInputStream fis = new FileInputStream(archive);
        XZCompressorInputStream xz = new XZCompressorInputStream(new BufferedInputStream(fis));
        extractTar(xz, destDir);
    }

    // ---------------------------------------------------------------- GZ / XZ

    private static void extractGz(File archive, File destDir) throws Exception {
        String name = archive.getName();
        if (name.toLowerCase(Locale.ROOT).endsWith(".gz")) {
            name = name.substring(0, name.length() - 3);
        }
        File out = new File(destDir, name);
        InputStream in = new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(archive)));
        OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            in.close();
            os.close();
        }
    }

    private static void extractXz(File archive, File destDir) throws Exception {
        String name = archive.getName();
        if (name.toLowerCase(Locale.ROOT).endsWith(".xz")) {
            name = name.substring(0, name.length() - 3);
        }
        File out = new File(destDir, name);
        InputStream in = new XZCompressorInputStream(new BufferedInputStream(new FileInputStream(archive)));
        OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            in.close();
            os.close();
        }
    }

    // ---------------------------------------------------------------- RAR

    private static void extractRar(File archive, File destDir) throws Exception {
        Archive a = new Archive(archive);
        try {
            FileHeader h;
            byte[] buf = new byte[65536];
            while ((h = a.nextFileHeader()) != null) {
                File out = safeChild(destDir, h.getFileNameString().replace('\\', '/'));
                if (h.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
                try {
                    InputStream is = a.getInputStream(h);
                    int n;
                    while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    os.close();
                }
            }
        } finally {
            a.close();
        }
    }

    // ---------------------------------------------------------------- COMPRESS: TAR.GZ

    public static void compressTarGz(java.util.List<File> files, File outFile) throws Exception {
        FileOutputStream fos = new FileOutputStream(outFile);
        GzipCompressorOutputStream gz = new GzipCompressorOutputStream(new BufferedOutputStream(fos));
        TarArchiveOutputStream tout = new TarArchiveOutputStream(gz);
        tout.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
        try {
            for (File f : files) addToTar(tout, f, f.getName());
        } finally {
            tout.close();
        }
    }

    private static void addToTar(TarArchiveOutputStream tout, File f, String entryName) throws Exception {
        if (f.isDirectory()) {
            if (!entryName.endsWith("/")) entryName += "/";
            TarArchiveEntry dir = new TarArchiveEntry(f, entryName);
            tout.putArchiveEntry(dir);
            tout.closeArchiveEntry();
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) addToTar(tout, k, entryName + k.getName());
            }
        } else {
            TarArchiveEntry e = new TarArchiveEntry(f, entryName);
            e.setSize(f.length());
            tout.putArchiveEntry(e);
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) tout.write(buf, 0, n);
            } finally {
                in.close();
            }
            tout.closeArchiveEntry();
        }
    }

    // ---------------------------------------------------------------- HELPERS

    /** Prevents ZipSlip: makes sure the entry stays inside destDir. */
    private static File safeChild(File destDir, String entryName) throws IOException {
        File out = new File(destDir, entryName);
        String dest = destDir.getCanonicalPath();
        String target = out.getCanonicalPath();
        if (!target.equals(dest) && !target.startsWith(dest + File.separator)) {
            throw new IOException("Unsafe entry: " + entryName);
        }
        return out;
    }
}