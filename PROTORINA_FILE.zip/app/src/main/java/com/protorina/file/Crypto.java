package com.protorina.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * File format "PFE2": magic(4) | salt(16) | iv(16) | AES-256-CTR ciphertext | HMAC-SHA256(32).
 * Keys come from PBKDF2-HMAC-SHA256 (100k iterations). Streams, so big files are fine.
 */
public class Crypto {
    private static final byte[] MAGIC = {'P', 'F', 'E', '2'};

    private static byte[][] keys(char[] pw, byte[] salt) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] k = f.generateSecret(new PBEKeySpec(pw, salt, 100000, 512)).getEncoded();
        return new byte[][] {Arrays.copyOfRange(k, 0, 32), Arrays.copyOfRange(k, 32, 64)};
    }

    public static void encrypt(File in, File out, char[] pw) throws Exception {
        SecureRandom r = new SecureRandom();
        byte[] salt = new byte[16];
        byte[] iv = new byte[16];
        r.nextBytes(salt);
        r.nextBytes(iv);
        byte[][] k = keys(pw, salt);
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(k[0], "AES"), new IvParameterSpec(iv));
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(k[1], "HmacSHA256"));
        OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
        InputStream is = new BufferedInputStream(new FileInputStream(in));
        try {
            byte[] head = new byte[36];
            System.arraycopy(MAGIC, 0, head, 0, 4);
            System.arraycopy(salt, 0, head, 4, 16);
            System.arraycopy(iv, 0, head, 20, 16);
            os.write(head);
            mac.update(head);
            byte[] buf = new byte[65536];
            int n;
            while ((n = is.read(buf)) > 0) {
                byte[] e = c.update(buf, 0, n);
                if (e != null) {
                    os.write(e);
                    mac.update(e);
                }
            }
            byte[] fin = c.doFinal();
            if (fin != null && fin.length > 0) {
                os.write(fin);
                mac.update(fin);
            }
            os.write(mac.doFinal());
        } finally {
            is.close();
            os.close();
        }
    }

    public static void decrypt(File in, File out, char[] pw) throws Exception {
        long len = in.length();
        if (len < 36 + 32) throw new IOException("This isn't a PROTORINA encrypted file");
        byte[] head = new byte[36];
        DataInputStream di = new DataInputStream(new BufferedInputStream(new FileInputStream(in)));
        try {
            di.readFully(head);
        } finally {
            di.close();
        }
        for (int i = 0; i < 4; i++) {
            if (head[i] != MAGIC[i]) throw new IOException("This isn't a PROTORINA encrypted file");
        }
        byte[] salt = Arrays.copyOfRange(head, 4, 20);
        byte[] iv = Arrays.copyOfRange(head, 20, 36);
        byte[][] k = keys(pw, salt);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(k[1], "HmacSHA256"));
        long body = len - 32;

        // pass 1: verify the MAC (also detects a wrong password)
        InputStream is = new BufferedInputStream(new FileInputStream(in));
        byte[] stored = new byte[32];
        try {
            byte[] buf = new byte[65536];
            long left = body;
            while (left > 0) {
                int n = is.read(buf, 0, (int) Math.min(buf.length, left));
                if (n < 0) throw new IOException("File is truncated");
                mac.update(buf, 0, n);
                left -= n;
            }
            int got = 0;
            while (got < 32) {
                int n = is.read(stored, got, 32 - got);
                if (n < 0) throw new IOException("File is truncated");
                got += n;
            }
        } finally {
            is.close();
        }
        if (!MessageDigest.isEqual(mac.doFinal(), stored)) {
            throw new SecurityException("Wrong password, or the file is damaged");
        }

        // pass 2: decrypt
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(k[0], "AES"), new IvParameterSpec(iv));
        InputStream is2 = new BufferedInputStream(new FileInputStream(in));
        OutputStream os = new BufferedOutputStream(new FileOutputStream(out));
        try {
            long skipped = 0;
            while (skipped < 36) {
                long s = is2.skip(36 - skipped);
                if (s <= 0) break;
                skipped += s;
            }
            byte[] buf = new byte[65536];
            long left = body - 36;
            while (left > 0) {
                int n = is2.read(buf, 0, (int) Math.min(buf.length, left));
                if (n < 0) throw new IOException("File is truncated");
                byte[] d = c.update(buf, 0, n);
                if (d != null) os.write(d);
                left -= n;
            }
            byte[] fin = c.doFinal();
            if (fin != null && fin.length > 0) os.write(fin);
        } finally {
            is2.close();
            os.close();
        }
    }

    public static String hash(File f, String algo) throws Exception {
        MessageDigest md = MessageDigest.getInstance(algo);
        InputStream is = new BufferedInputStream(new FileInputStream(f));
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = is.read(buf)) > 0) md.update(buf, 0, n);
        } finally {
            is.close();
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
