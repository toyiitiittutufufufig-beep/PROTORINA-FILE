package com.protorina.file;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Tabbed text editor with syntax colors, undo/redo, find & replace and a symbol row. */
public class EditorView extends LinearLayout {
    private static final int MAX_EDIT = 5 * 1024 * 1024;
    private static final int PREVIEW = 512 * 1024;

    private static class Doc {
        File file;
        String text = "";
        boolean modified;
        boolean readOnly;
        final List<String> hist = new ArrayList<String>();
        int hi = -1;
    }

    private static class Ed extends EditText {
        Runnable onSel;

        Ed(Context c) {
            super(c);
        }

        @Override
        protected void onSelectionChanged(int s, int e) {
            super.onSelectionChanged(s, e);
            if (onSel != null) onSel.run();
        }
    }

    private final MainActivity act;
    private final List<Doc> docs = new ArrayList<Doc>();
    private int cur = -1;
    private boolean loading = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Ed ed;
    private TextView title, status, empty;
    private LinearLayout tabsRow;
    private HorizontalScrollView tabsScroll;
    private LinearLayout keys;

    private final Runnable idle = new Runnable() {
        @Override
        public void run() {
            if (cur < 0) return;
            Doc d = docs.get(cur);
            Highlighter.apply(ed.getText(), Fs.ext(d.file));
            if (ed.length() < 300000) {
                String t = ed.getText().toString();
                if (d.hi < 0 || !d.hist.get(d.hi).equals(t)) {
                    while (d.hist.size() > d.hi + 1) d.hist.remove(d.hist.size() - 1);
                    d.hist.add(t);
                    if (d.hist.size() > 40) d.hist.remove(0);
                    d.hi = d.hist.size() - 1;
                }
            }
        }
    };

    public EditorView(MainActivity a) {
        super(a);
        act = a;
        setOrientation(VERTICAL);
        setBackgroundColor(T.bg);

        LinearLayout head = new LinearLayout(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(a, 16), Ui.dp(a, 8), Ui.dp(a, 4), 0);
        title = Ui.text(a, "Editor", 18, T.tx, true);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        head.addView(title, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageView bUndo = Ui.iconBtn(a, R.drawable.ic_undo, "Undo");
        ImageView bRedo = Ui.iconBtn(a, R.drawable.ic_redo, "Redo");
        ImageView bFind = Ui.iconBtn(a, R.drawable.ic_search, "Find and replace");
        ImageView bSave = Ui.iconBtn(a, R.drawable.ic_save, "Save");
        ImageView bClose = Ui.iconBtn(a, R.drawable.ic_close, "Close file");
        head.addView(bUndo);
        head.addView(bRedo);
        head.addView(bFind);
        head.addView(bSave);
        head.addView(bClose);
        addView(head);

        tabsScroll = new HorizontalScrollView(a);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        tabsRow = new LinearLayout(a);
        tabsRow.setPadding(Ui.dp(a, 12), Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 4));
        tabsScroll.addView(tabsRow);
        addView(tabsScroll);

        FrameLayoutHolder body = new FrameLayoutHolder(a);
        ed = new Ed(a);
        ed.setBackground(null);
        ed.setTypeface(Typeface.MONOSPACE);
        ed.setTextSize(13);
        ed.setTextColor(T.tx);
        ed.setHintTextColor(T.mu);
        ed.setGravity(Gravity.TOP | Gravity.START);
        ed.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ed.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
        ed.setVisibility(GONE);
        empty = Ui.text(a, "Open a file from the Files tab to edit it", 14, T.mu, false);
        empty.setGravity(Gravity.CENTER);
        body.addView(ed, new android.widget.FrameLayout.LayoutParams(-1, -1));
        body.addView(empty, new android.widget.FrameLayout.LayoutParams(-1, -1));
        addView(body, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        keys = new LinearLayout(a);
        keys.setBackgroundColor(T.sf);
        keys.setPadding(Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4));
        String[] k = {"Tab", "{ }", "( )", "[ ]", ";", "=", "\"", "/"};
        for (final String s : k) {
            TextView b = Ui.mono(a, s, 14, T.tx);
            b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            b.setGravity(Gravity.CENTER);
            b.setBackground(Ui.shape(a, T.ib, 10, 0));
            LayoutParams lp = new LayoutParams(0, Ui.dp(a, 42), 1f);
            lp.setMargins(Ui.dp(a, 3), 0, Ui.dp(a, 3), 0);
            b.setOnClickListener(v -> insertKey(s));
            keys.addView(b, lp);
        }
        keys.setVisibility(GONE);
        addView(keys);

        status = Ui.mono(a, "", 11, T.mu);
        status.setBackgroundColor(T.sf);
        status.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 4));
        addView(status);

        ed.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void afterTextChanged(Editable e) {
                if (loading || cur < 0) return;
                Doc d = docs.get(cur);
                if (!d.modified) {
                    d.modified = true;
                    refreshTabs();
                }
                handler.removeCallbacks(idle);
                handler.postDelayed(idle, 500);
                updateStatus();
            }
        });
        ((Ed) ed).onSel = this::updateStatus;

        bSave.setOnClickListener(v -> save());
        bClose.setOnClickListener(v -> closeCurrent());
        bUndo.setOnClickListener(v -> stepHistory(-1));
        bRedo.setOnClickListener(v -> stepHistory(1));
        bFind.setOnClickListener(v -> findDialog());
        refreshTabs();
    }

    // tiny alias so the file doesn't need another import line
    private static class FrameLayoutHolder extends android.widget.FrameLayout {
        FrameLayoutHolder(Context c) {
            super(c);
        }
    }

    public boolean hasUnsaved() {
        for (Doc d : docs) if (d.modified) return true;
        return false;
    }

    public void open(File f) {
        for (int i = 0; i < docs.size(); i++) {
            if (docs.get(i).file.equals(f)) {
                show(i);
                return;
            }
        }
        Doc d = new Doc();
        d.file = f;
        try {
            if (f.length() > MAX_EDIT) {
                d.text = Fs.readText(f, PREVIEW);
                d.readOnly = true;
                Ui.toastLong(act, "Big file: showing the first 512 KB read-only. Large-file editing is coming next.");
            } else {
                d.text = Fs.readText(f, MAX_EDIT);
            }
        } catch (Exception e) {
            Ui.toastLong(act, "Can't open this file: " + e.getMessage());
            return;
        }
        docs.add(d);
        show(docs.size() - 1);
    }

    private void stash() {
        if (cur >= 0 && cur < docs.size()) docs.get(cur).text = ed.getText().toString();
    }

    private void show(int i) {
        stash();
        cur = i;
        Doc d = docs.get(i);
        loading = true;
        ed.setText(d.text);
        ed.setEnabled(true);
        ed.setFocusable(!d.readOnly);
        ed.setFocusableInTouchMode(!d.readOnly);
        ed.setCursorVisible(!d.readOnly);
        loading = false;
        if (d.hist.isEmpty()) {
            d.hist.add(d.text);
            d.hi = 0;
        }
        Highlighter.apply(ed.getText(), Fs.ext(d.file));
        ed.setVisibility(VISIBLE);
        empty.setVisibility(GONE);
        keys.setVisibility(d.readOnly ? GONE : VISIBLE);
        refreshTabs();
        updateStatus();
    }

    private void refreshTabs() {
        tabsRow.removeAllViews();
        title.setText(cur >= 0 ? docs.get(cur).file.getName() : "Editor");
        for (int i = 0; i < docs.size(); i++) {
            final int idx = i;
            Doc d = docs.get(i);
            TextView t = Ui.pill(act, d.file.getName() + (d.modified ? " ●" : ""), i == cur);
            LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(act, 8);
            t.setOnClickListener(v -> show(idx));
            tabsRow.addView(t, lp);
        }
        tabsScroll.setVisibility(docs.isEmpty() ? GONE : VISIBLE);
    }

    private void updateStatus() {
        if (cur < 0) {
            status.setText("");
            return;
        }
        Doc d = docs.get(cur);
        int pos = Math.max(0, ed.getSelectionStart());
        CharSequence t = ed.getText();
        int line = 1;
        int col = 1;
        int end = Math.min(pos, t.length());
        for (int i = 0; i < end; i++) {
            if (t.charAt(i) == '\n') {
                line++;
                col = 1;
            } else {
                col++;
            }
        }
        status.setText("UTF-8 · Ln " + line + ", Col " + col + " · " + Fs.human(d.file.length()) + (d.readOnly ? " · read-only" : ""));
    }

    private void save() {
        if (cur < 0) return;
        Doc d = docs.get(cur);
        if (d.readOnly) {
            Ui.toast(act, "This file is read-only");
            return;
        }
        try {
            Fs.writeText(d.file, ed.getText().toString());
            d.modified = false;
            refreshTabs();
            updateStatus();
            Ui.toast(act, "Saved");
        } catch (Exception e) {
            Ui.toastLong(act, "Couldn't save: " + e.getMessage());
        }
    }

    private void closeCurrent() {
        if (cur < 0) return;
        final Doc d = docs.get(cur);
        if (d.modified) {
            Ui.dlg(act).setMessage("Save changes to " + d.file.getName() + "?")
                    .setPositiveButton("Save", (x, w) -> {
                        save();
                        removeCurrent();
                    })
                    .setNegativeButton("Discard", (x, w) -> removeCurrent())
                    .setNeutralButton("Cancel", null).show();
        } else {
            removeCurrent();
        }
    }

    private void removeCurrent() {
        docs.remove(cur);
        cur = -1;
        if (docs.isEmpty()) {
            loading = true;
            ed.setText("");
            loading = false;
            ed.setVisibility(GONE);
            empty.setVisibility(VISIBLE);
            keys.setVisibility(GONE);
            refreshTabs();
            updateStatus();
        } else {
            show(docs.size() - 1);
        }
    }

    private void stepHistory(int dir) {
        if (cur < 0) return;
        Doc d = docs.get(cur);
        if (d.readOnly) return;
        handler.removeCallbacks(idle);
        idle.run();
        int n = d.hi + dir;
        if (n < 0 || n >= d.hist.size()) return;
        d.hi = n;
        loading = true;
        int pos = ed.getSelectionStart();
        ed.setText(d.hist.get(n));
        ed.setSelection(Math.max(0, Math.min(pos, ed.length())));
        loading = false;
        d.modified = true;
        Highlighter.apply(ed.getText(), Fs.ext(d.file));
        refreshTabs();
    }

    private void insertKey(String s) {
        if (cur < 0 || docs.get(cur).readOnly) return;
        int st = Math.max(0, ed.getSelectionStart());
        int en = Math.max(0, ed.getSelectionEnd());
        String ins = s;
        int back = 0;
        if (s.equals("Tab")) ins = "    ";
        else if (s.equals("{ }")) { ins = "{}"; back = 1; }
        else if (s.equals("( )")) { ins = "()"; back = 1; }
        else if (s.equals("[ ]")) { ins = "[]"; back = 1; }
        else if (s.equals("\"")) { ins = "\"\""; back = 1; }
        ed.getText().replace(Math.min(st, en), Math.max(st, en), ins);
        ed.setSelection(Math.min(st, en) + ins.length() - back);
    }

    private void findDialog() {
        if (cur < 0) return;
        final EditText f = Ui.field(act, "Find", "", false);
        final EditText r = Ui.field(act, "Replace with", "", false);
        AlertDialog dlg = Ui.dlg(act).setTitle("Find & replace").setView(Ui.box(act, f, r))
                .setPositiveButton("Next", null)
                .setNeutralButton("Replace all", null)
                .setNegativeButton("Close", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String q = f.getText().toString();
            if (q.length() == 0) return;
            String t = ed.getText().toString();
            int from = Math.max(ed.getSelectionEnd(), 0);
            int i = t.indexOf(q, from);
            if (i < 0) i = t.indexOf(q);
            if (i < 0) {
                Ui.toast(act, "Not found");
                return;
            }
            ed.requestFocus();
            ed.setSelection(i, i + q.length());
        });
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
            String q = f.getText().toString();
            if (q.length() == 0 || docs.get(cur).readOnly) return;
            String t = ed.getText().toString();
            int count = 0;
            int idx = 0;
            while ((idx = t.indexOf(q, idx)) >= 0) {
                count++;
                idx += q.length();
            }
            if (count == 0) {
                Ui.toast(act, "Not found");
                return;
            }
            ed.setText(t.replace(q, r.getText().toString()));
            Ui.toast(act, "Replaced " + count);
        });
    }
}
