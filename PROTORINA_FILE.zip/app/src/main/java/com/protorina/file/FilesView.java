package com.protorina.file;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Environment;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Two-pane file manager. Copy / Move always go to the other pane's folder. */
public class FilesView extends LinearLayout {
    private final MainActivity act;
    private final File root;
    private final File[] cwd = new File[2];
    private int pane = 0;
    private final Set<File> sel = new LinkedHashSet<File>();
    private final List<File> items = new ArrayList<File>();
    private boolean hasUp = false;
    private String filter = "";
    private ListView list;
    private BaseAdapter adapter;
    private TextView pathBar, tab0, tab1, selCount;
    private LinearLayout selBar, searchRow;
    private EditText search;
    private final SimpleDateFormat df = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());

    private static class Row extends LinearLayout {
        final FrameLayout box;
        final ImageView folder;
        final TextView label, name, meta;

        Row(MainActivity a) {
            super(a);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(Ui.dp(a, 16), Ui.dp(a, 8), Ui.dp(a, 16), Ui.dp(a, 8));
            box = new FrameLayout(a);
            folder = Ui.icon(a, R.drawable.ic_folder, T.ac, 9);
            label = Ui.text(a, "", 11, T.mu, true);
            label.setGravity(Gravity.CENTER);
            box.addView(folder, new FrameLayout.LayoutParams(-1, -1));
            box.addView(label, new FrameLayout.LayoutParams(-1, -1));
            addView(box, new LayoutParams(Ui.dp(a, 40), Ui.dp(a, 40)));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(VERTICAL);
            col.setPadding(Ui.dp(a, 12), 0, 0, 0);
            name = Ui.text(a, "", 14, T.tx, true);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            meta = Ui.text(a, "", 12, T.mu, false);
            meta.setSingleLine(true);
            col.addView(name);
            col.addView(meta);
            addView(col, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
    }

    public FilesView(MainActivity a) {
        super(a);
        act = a;
        root = Environment.getExternalStorageDirectory().exists()
                ? Environment.getExternalStorageDirectory() : a.getFilesDir();
        cwd[0] = root;
        cwd[1] = root;
        setOrientation(VERTICAL);
        setBackgroundColor(T.bg);

        // header
        LinearLayout head = new LinearLayout(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(a, 16), Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 4));
        View logo = new View(a);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {T.ac, T.ac2});
        g.setCornerRadius(Ui.dp(a, 8));
        logo.setBackground(g);
        head.addView(logo, new LayoutParams(Ui.dp(a, 26), Ui.dp(a, 26)));
        TextView title = Ui.text(a, "PROTORINA FILE", 18, T.tx, true);
        title.setPadding(Ui.dp(a, 10), 0, 0, 0);
        head.addView(title, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageView bSearch = Ui.iconBtn(a, R.drawable.ic_search, "Search");
        ImageView bTheme = Ui.iconBtn(a, R.drawable.ic_moon, "Toggle theme");
        ImageView bPlus = Ui.iconBtn(a, R.drawable.ic_plus, "New");
        head.addView(bSearch);
        head.addView(bTheme);
        head.addView(bPlus);
        addView(head);

        // tabs
        LinearLayout tabs = new LinearLayout(a);
        tabs.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 4));
        tab0 = Ui.pill(a, "", true);
        tab1 = Ui.pill(a, "", false);
        LayoutParams tl = new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tl.rightMargin = Ui.dp(a, 8);
        tabs.addView(tab0, tl);
        tabs.addView(tab1, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        addView(tabs);

        // search row
        searchRow = new LinearLayout(a);
        searchRow.setPadding(Ui.dp(a, 16), 0, Ui.dp(a, 16), Ui.dp(a, 4));
        searchRow.setVisibility(GONE);
        search = new EditText(a);
        search.setHint("Filter by name");
        search.setHintTextColor(T.mu);
        search.setTextColor(T.tx);
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setBackground(Ui.shape(a, T.ib, 10, 0));
        search.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
        searchRow.addView(search, new LayoutParams(-1, -2));
        addView(searchRow);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a1, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a1, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                filter = e.toString();
                reload();
            }
        });

        pathBar = Ui.mono(a, "", 12, T.mu);
        pathBar.setSingleLine(true);
        pathBar.setEllipsize(TextUtils.TruncateAt.START);
        pathBar.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 6));
        addView(pathBar);

        list = new ListView(a);
        list.setDivider(null);
        list.setBackgroundColor(T.bg);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return items.size() + (hasUp ? 1 : 0); }
            @Override public Object getItem(int p) { return at(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View convert, ViewGroup parent) {
                Row r = convert instanceof Row ? (Row) convert : new Row(act);
                bind(r, p);
                return r;
            }
        };
        list.setAdapter(adapter);
        addView(list, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        list.setOnItemClickListener((p, v, pos, id) -> onTap(pos));
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            if (!(hasUp && pos == 0)) toggle(at(pos));
            return true;
        });

        // selection bar
        selBar = new LinearLayout(a);
        selBar.setGravity(Gravity.CENTER_VERTICAL);
        selBar.setBackgroundColor(T.sf);
        selBar.setPadding(Ui.dp(a, 12), Ui.dp(a, 2), Ui.dp(a, 4), Ui.dp(a, 2));
        selCount = Ui.text(a, "", 12, T.mu, false);
        selBar.addView(selCount, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        selBar.addView(actionBtn("Copy", () -> copyMove(false)));
        selBar.addView(actionBtn("Move", () -> copyMove(true)));
        selBar.addView(actionBtn("Zip", () -> Actions.compress(act, new ArrayList<File>(sel), cwd[pane], this::afterOp)));
        selBar.addView(actionBtn("Delete", this::deleteSel));
        selBar.addView(actionBtn("More", this::more));
        selBar.setVisibility(GONE);
        addView(selBar);

        tab0.setOnClickListener(v -> switchPane(0));
        tab1.setOnClickListener(v -> switchPane(1));
        bSearch.setOnClickListener(v -> {
            boolean show = searchRow.getVisibility() != VISIBLE;
            searchRow.setVisibility(show ? VISIBLE : GONE);
            if (!show) search.setText("");
        });
        bTheme.setOnClickListener(v -> act.toggleTheme());
        bPlus.setOnClickListener(v -> Ui.dlg(act).setItems(new String[] {"New folder", "New file"}, (d, w) -> {
            if (w == 0) Actions.newFolder(act, cwd[pane], this::afterOp);
            else Actions.newFile(act, cwd[pane], this::afterOp);
        }).show());
        reload();
    }

    private TextView actionBtn(String s, final Runnable r) {
        TextView t = Ui.text(act, s, 13, T.ac, true);
        t.setPadding(Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private File at(int pos) {
        if (hasUp) return pos == 0 ? cwd[pane].getParentFile() : items.get(pos - 1);
        return items.get(pos);
    }

    private void bind(Row r, int pos) {
        File f = at(pos);
        boolean up = hasUp && pos == 0;
        r.setBackgroundColor(!up && sel.contains(f) ? T.tn : Color.TRANSPARENT);
        r.box.setBackground(Ui.shape(act, T.ib, 12, 0));
        if (up || f.isDirectory()) {
            r.folder.setVisibility(VISIBLE);
            r.folder.setColorFilter(T.ac);
            r.label.setVisibility(GONE);
            r.name.setText(up ? ".." : f.getName());
            r.meta.setText(up ? "Parent folder" : "Folder · " + df.format(new Date(f.lastModified())));
        } else {
            r.folder.setVisibility(GONE);
            r.label.setVisibility(VISIBLE);
            r.label.setText(Fs.label(f));
            r.label.setTextColor(T.kindColor(Fs.kind(f)));
            r.name.setText(f.getName());
            r.meta.setText(Fs.human(f.length()) + " · " + df.format(new Date(f.lastModified())));
        }
    }

    private void reload() {
        File dir = cwd[pane];
        items.clear();
        File[] fs = dir.listFiles();
        if (fs == null) {
            Ui.toast(act, "Can't open this folder");
        } else {
            String q = filter.toLowerCase(Locale.ROOT);
            List<File> l = new ArrayList<File>();
            for (File f : fs) if (q.length() == 0 || f.getName().toLowerCase(Locale.ROOT).contains(q)) l.add(f);
            Collections.sort(l, (a, b) -> {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
            items.addAll(l);
        }
        hasUp = dir.getParentFile() != null;
        java.util.Iterator<File> it = sel.iterator();
        while (it.hasNext()) if (!it.next().exists()) it.remove();
        tab0.setText(name(cwd[0]));
        tab1.setText(name(cwd[1]));
        tab0.setTextColor(pane == 0 ? T.ac : T.mu);
        tab0.setBackground(Ui.shape(act, pane == 0 ? T.tn : T.ib, 20, 0));
        tab1.setTextColor(pane == 1 ? T.ac : T.mu);
        tab1.setBackground(Ui.shape(act, pane == 1 ? T.tn : T.ib, 20, 0));
        pathBar.setText(dir.getAbsolutePath());
        adapter.notifyDataSetChanged();
        updateSel();
    }

    private String name(File f) {
        return f.equals(root) ? "Storage" : (f.getName().length() == 0 ? "/" : f.getName());
    }

    private void updateSel() {
        selBar.setVisibility(sel.isEmpty() ? GONE : VISIBLE);
        selCount.setText(sel.size() + " selected");
    }

    private void switchPane(int p) {
        pane = p;
        sel.clear();
        reload();
    }

    private void go(File d) {
        cwd[pane] = d;
        sel.clear();
        reload();
        list.setSelection(0);
    }

    /** Back button: clear selection, then go up a folder; false = nothing left to do. */
    public boolean back() {
        if (!sel.isEmpty()) {
            sel.clear();
            reload();
            return true;
        }
        File p = cwd[pane].getParentFile();
        if (cwd[pane].equals(root) || p == null) return false;
        go(p);
        return true;
    }

    private void onTap(int pos) {
        if (hasUp && pos == 0) {
            go(cwd[pane].getParentFile());
            return;
        }
        File f = at(pos);
        if (!sel.isEmpty()) toggle(f);
        else openItem(f);
    }

    private void toggle(File f) {
        if (!sel.remove(f)) sel.add(f);
        adapter.notifyDataSetChanged();
        updateSel();
    }

    private void afterOp() {
        sel.clear();
        reload();
    }

    private void openItem(final File f) {
        if (f.isDirectory()) {
            go(f);
            return;
        }
        String e = Fs.ext(f);
        if ("zip".equals(e) || "jar".equals(e)) {
            Ui.dlg(act).setTitle(f.getName()).setItems(new String[] {"Extract", "Open as text"}, (d, w) -> {
                if (w == 0) Actions.extract(act, f, this::afterOp);
                else act.openInEditor(f);
            }).show();
        } else if ("pfe".equals(e)) {
            Actions.decrypt(act, f, this::afterOp);
        } else if (Fs.isText(f)) {
            act.openInEditor(f);
        } else {
            Ui.dlg(act).setTitle(f.getName()).setItems(new String[] {"Open with another app", "Edit as text", "Hash"}, (d, w) -> {
                if (w == 0) Actions.openWith(act, f, false);
                else if (w == 1) act.openInEditor(f);
                else Actions.hash(act, f);
            }).show();
        }
    }

    private void copyMove(final boolean move) {
        final File dst = cwd[1 - pane];
        final List<File> s = new ArrayList<File>(sel);
        Actions.work(act, move ? "Moving…" : "Copying…", () -> {
            for (File f : s) {
                if (move) {
                    if (!f.getParentFile().equals(dst)) Fs.move(f, dst);
                } else {
                    Fs.copy(f, Fs.unique(dst, f.getName()));
                }
            }
        }, this::afterOp);
        Ui.toast(act, (move ? "Moving to " : "Copying to ") + name(dst));
    }

    private void deleteSel() {
        final List<File> s = new ArrayList<File>(sel);
        Ui.confirm(act, "Delete " + s.size() + (s.size() == 1 ? " item?" : " items?") + " This can't be undone.", "Delete",
                () -> Actions.work(act, "Deleting…", () -> {
                    for (File f : s) Fs.delete(f);
                }, this::afterOp));
    }

    private void more() {
        final List<String> opts = new ArrayList<String>();
        final boolean one = sel.size() == 1;
        final File f = one ? sel.iterator().next() : null;
        if (one) opts.add("Rename");
        if (one) opts.add("Info");
        if (one && f.isFile()) {
            opts.add("Hash");
            opts.add("Encrypt");
            opts.add("Share");
            if ("zip".equals(Fs.ext(f))) opts.add("Extract");
        }
        opts.add("Select all");
        Ui.dlg(act).setItems(opts.toArray(new String[0]), (d, w) -> {
            String o = opts.get(w);
            if (o.equals("Rename")) Actions.rename(act, f, this::afterOp);
            else if (o.equals("Info")) Actions.info(act, f);
            else if (o.equals("Hash")) Actions.hash(act, f);
            else if (o.equals("Encrypt")) Actions.encrypt(act, f, this::afterOp);
            else if (o.equals("Share")) Actions.openWith(act, f, true);
            else if (o.equals("Extract")) Actions.extract(act, f, this::afterOp);
            else if (o.equals("Select all")) {
                sel.addAll(items);
                adapter.notifyDataSetChanged();
                updateSel();
            }
        }).show();
    }
}
