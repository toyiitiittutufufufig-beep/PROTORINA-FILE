package com.protorina.file;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class Fs {
    private static final Set<String> TEXT = new HashSet<String>(Arrays.asList(
            "txt", "md", "json", "xml", "html", "htm", "css", "js", "mjs", "ts", "jsx", "tsx", "java", "kt", "py",
            "sh", "c", "cpp", "h", "hpp", "cs", "go", "rs", "php", "rb", "yml", "yaml", "ini", "conf", "cfg",
            "properties", "gradle", "sql", "csv", "log", "bat", "smali", "vue", "toml", "env", "gitignore", "lua"));
    private static final Set<String> ARCH = new HashSet<String>(Arrays.asList(
            "zip", "rar", "7z", "tar", "gz", "tgz", "xz", "bz2", "pfe", "jar"));
    private static final Set<String> IMG = new HashSet<String>(Arrays.asList(
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic"));

    public static boolean hasAllFiles(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    public static String ext(File f) {
        String n = f.getName();
        int i = n.lastIndexOf('.');
        return i < 0 || i == n.length() - 1 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    public static String kind(File f) {
        if (f.isDirectory()) return "folder";
        String e = ext(f);
        if (TEXT.contains(e)) return "code";
        if (ARCH.contains(e)) return "arch";
        if (IMG.contains(e)) return "img";
        if ("apk".equals(e) || "xapk".equals(e) || "apks".equals(e)) return "apk";
        if ("db".equals(e) || "sqlite".equals(e) || "sqlite3".equals(e)) return "db";
        return "other";
    }

    public static String label(File f) {
        String e = ext(f).toUpperCase(Locale.ROOT);
        if (e.length() == 0) return "FILE";
        return e.length() > 4 ? e.substring(0, 4) : e;
    }

    public static boolean isText(File f) {
        if (TEXT.contains(ext(f))) return true;
        InputStream in = null;
        try {
            in = new FileInputStream(f);
            byte[] b = new byte[2048];
            int n = in.read(b);
            for (int i = 0; i < n; i++) if (b[i] == 0) return false;
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            if (in != null) try { in.close(); } catch (IOException e) { /* ignore */ }
        }
    }

    public static String human(long b) {
        if (b < 1024) return b + " B";
        double v = b;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = -1;
        while (v >= 1024 && i < 3) { v /= 1024; i++; }
        return (v >= 100 ? String.valueOf(Math.round(v)) : String.format(Locale.US, "%.1f", v)) + " " + u[i];
    }

    public static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        String base = name;
        String ex = "";
        int i = name.lastIndexOf('.');
        if (i > 0) { base = name.substring(0, i); ex = name.substring(i); }
        for (int n = 1; n < 10000; n++) {
            f = new File(dir, base + " (" + n + ")" + ex);
            if (!f.exists()) return f;
        }
        return f;
    }

    public static void copy(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            String sp = src.getCanonicalPath();
            String dp = dst.getCanonicalPath();
            if (dp.equals(sp) || dp.startsWith(sp + "/")) throw new IOException("Can't copy a folder into itself");
            if (!dst.mkdirs() && !dst.isDirectory()) throw new IOException("Can't create " + dst.getName());
            File[] kids = src.listFiles();
            if (kids != null) for (File k : kids) copy(k, new File(dst, k.getName()));
        } else {
            InputStream in = new BufferedInputStream(new FileInputStream(src));
            OutputStream out = new FileOutputStream(dst);
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                in.close();
                out.close();
            }
        }
    }

    public static void delete(File f) throws IOException {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) delete(k);
        }
        if (!f.delete() && f.exists()) throw new IOException("Can't delete " + f.getName());
    }

    public static void move(File src, File dstDir) throws IOException {
        File dst = unique(dstDir, src.getName());
        if (src.renameTo(dst)) return;
        copy(src, dst);
        delete(src);
    }

    public static String readText(File f, int maxBytes) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            int total = 0;
            while ((n = in.read(buf)) > 0 && total < maxBytes) {
                int take = Math.min(n, maxBytes - total);
                bos.write(buf, 0, take);
                total += take;
            }
            return new String(bos.toByteArray(), "UTF-8");
        } finally {
            in.close();
        }
    }

    public static void writeText(File f, String s) throws IOException {
        OutputStream out = new FileOutputStream(f);
        try {
            out.write(s.getBytes("UTF-8"));
        } finally {
            out.close();
        }
    }
}
