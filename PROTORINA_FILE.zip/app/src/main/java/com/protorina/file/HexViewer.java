package com.protorina.file;

import android.app.Activity;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.RandomAccessFile;

/**
 * Hex viewer/editor. Reads chunks of a file, shows offset | hex | ascii,
 * allows editing a byte and saving back.
 */
public class HexViewer {

    private static final int ROW_BYTES = 16;      // bytes per row
    private static final int ROWS_PER_PAGE = 64;  // 1KB per page

    public static void show(final Activity a, final File f) {
        final long fileLen = f.length();

        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);

        // ---- toolbar
        final LinearLayout bar = new LinearLayout(a);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8));
        bar.setBackgroundColor(T.sf);

        final TextView info = Ui.mono(a, "", 11, T.mu);
        info.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(info);

        TextView prev = Ui.text(a, "◀ Prev", 12, T.ac, true);
        prev.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        bar.addView(prev);

        TextView next = Ui.text(a, "Next ▶", 12, T.ac, true);
        next.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        bar.addView(next);

        TextView gotoBtn = Ui.text(a, "Go to", 12, T.ac, true);
        gotoBtn.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        bar.addView(gotoBtn);

        TextView findBtn = Ui.text(a, "Find", 12, T.ac, true);
        findBtn.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        bar.addView(findBtn);

        TextView saveBtn = Ui.text(a, "Save", 12, T.ac2, true);
        saveBtn.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        bar.addView(saveBtn);

        root.addView(bar);

        // ---- hex content
        final TextView hexView = Ui.mono(a, "", 11, T.tx);
        hexView.setTextIsSelectable(true);
        hexView.setPadding(Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8));

        HorizontalScrollView hsv = new HorizontalScrollView(a);
        hsv.addView(hexView);

        ScrollView sv = new ScrollView(a);
        sv.addView(hsv);
        root.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final android.app.AlertDialog dlg = Ui.dlg(a)
                .setTitle(f.getName())
                .setView(root)
                .setNegativeButton("Close", null)
                .create();
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }

        final long[] offset = {0};
        final byte[][] buffer = {null};
        final boolean[] dirty = {false};

        Runnable refresh = () -> {
            try {
                long start = offset[0];
                long len = Math.min(ROWS_PER_PAGE * ROW_BYTES, fileLen - start);
                if (len <= 0) { hexView.setText("(end of file)"); return; }
                byte[] data = new byte[(int) len];
                RandomAccessFile raf = new RandomAccessFile(f, "r");
                try {
                    raf.seek(start);
                    raf.readFully(data);
                } finally {
                    raf.close();
                }
                buffer[0] = data;

                StringBuilder sb = new StringBuilder();
                for (int row = 0; row < data.length; row += ROW_BYTES) {
                    long rowOffset = start + row;
                    sb.append(String.format("%08X  ", rowOffset));
                    StringBuilder ascii = new StringBuilder();
                    for (int i = 0; i < ROW_BYTES; i++) {
                        if (row + i < data.length) {
                            int b = data[row + i] & 0xFF;
                            sb.append(String.format("%02X ", b));
                            ascii.append(b >= 32 && b < 127 ? (char) b : '.');
                        } else {
                            sb.append("   ");
                            ascii.append(' ');
                        }
                        if (i == 7) sb.append(' ');
                    }
                    sb.append(" |").append(ascii).append("|\n");
                }
                hexView.setText(sb.toString());
                long end = start + data.length;
                long pct = fileLen == 0 ? 100 : (end * 100 / fileLen);
                info.setText(Fs.human(fileLen) + "  ·  "
                        + String.format("%08X", start) + " - " + String.format("%08X", end)
                        + "  (" + pct + "%)" + (dirty[0] ? "  ●" : ""));
            } catch (Exception e) {
                hexView.setText("Error: " + e.getMessage());
            }
        };

        refresh.run();

        prev.setOnClickListener(v -> {
            long step = ROWS_PER_PAGE * ROW_BYTES;
            offset[0] = Math.max(0, offset[0] - step);
            refresh.run();
        });

        next.setOnClickListener(v -> {
            long step = ROWS_PER_PAGE * ROW_BYTES;
            long newOff = offset[0] + step;
            if (newOff >= fileLen) newOff = Math.max(0, fileLen - step);
            offset[0] = newOff;
            refresh.run();
        });

        gotoBtn.setOnClickListener(v -> {
            final EditText e = Ui.field(a, "Offset (hex or decimal)", "", false);
            Ui.dlg(a).setTitle("Go to offset").setView(Ui.box(a, e))
                    .setPositiveButton("Go", (d, w) -> {
                        String s = e.getText().toString().trim();
                        if (s.length() == 0) return;
                        try {
                            long off;
                            if (s.startsWith("0x") || s.startsWith("0X")) {
                                off = Long.parseLong(s.substring(2), 16);
                            } else if (s.matches("[0-9A-Fa-f]+") && s.length() >= 4) {
                                off = Long.parseLong(s, 16);
                            } else {
                                off = Long.parseLong(s);
                            }
                            offset[0] = Math.max(0, Math.min(off, fileLen - 1));
                            refresh.run();
                        } catch (Exception ex) {
                            Ui.toast(a, "Invalid offset");
                        }
                    })
                    .setNegativeButton("Cancel", null).show();
        });

        findBtn.setOnClickListener(v -> {
            final EditText e = Ui.field(a, "Hex bytes (e.g. 4A 6F 68 6E) or ASCII text", "", false);
            Ui.dlg(a).setTitle("Find").setView(Ui.box(a, e))
                    .setPositiveButton("Find", (d, w) -> {
                        String s = e.getText().toString().trim();
                        if (s.length() == 0) return;
                        byte[] needle = parseNeedle(s);
                        if (needle == null || needle.length == 0) {
                            Ui.toast(a, "Invalid search");
                            return;
                        }
                        new Thread(() -> {
                            long found = searchInFile(f, needle, 0);
                            a.runOnUiThread(() -> {
                                if (found >= 0) {
                                    offset[0] = (found / (ROWS_PER_PAGE * ROW_BYTES)) * (ROWS_PER_PAGE * ROW_BYTES);
                                    refresh.run();
                                    Ui.toast(a, "Found at 0x" + Long.toHexString(found).toUpperCase());
                                } else {
                                    Ui.toast(a, "Not found");
                                }
                            });
                        }).start();
                    })
                    .setNegativeButton("Cancel", null).show();
        });

        saveBtn.setOnClickListener(v -> {
            if (!dirty[0]) {
                Ui.toast(a, "No changes to save");
                return;
            }
            Ui.toast(a, "Save: not yet wired (coming in next update)");
        });

        // Tap on a hex byte to edit
        hexView.setOnClickListener(v -> {
            if (buffer[0] == null) return;
            final EditText offE = Ui.field(a, "Offset within page (decimal)", "0", false);
            final EditText valE = Ui.field(a, "New value (hex, e.g. FF)", "", false);
            Ui.dlg(a).setTitle("Edit byte")
                    .setView(Ui.box(a, offE, valE))
                    .setPositiveButton("Apply", (d, w) -> {
                        try {
                            int rel = Integer.parseInt(offE.getText().toString().trim());
                            if (rel < 0 || rel >= buffer[0].length) {
                                Ui.toast(a, "Offset out of range");
                                return;
                            }
                            String hex = valE.getText().toString().trim().replace("0x", "").replace("0X", "");
                            int val = Integer.parseInt(hex, 16) & 0xFF;
                            byte[] old = buffer[0];
                            byte[] mod = new byte[old.length];
                            System.arraycopy(old, 0, mod, 0, old.length);
                            mod[rel] = (byte) val;

                            long pos = offset[0] + rel;
                            RandomAccessFile raf = new RandomAccessFile(f, "rw");
                            try {
                                raf.seek(pos);
                                raf.write(mod[rel]);
                            } finally {
                                raf.close();
                            }
                            dirty[0] = true;
                            refresh.run();
                            Ui.toast(a, "Changed byte at 0x" + Long.toHexString(pos).toUpperCase()
                                    + " to 0x" + String.format("%02X", val));
                        } catch (Exception ex) {
                            Ui.toast(a, "Invalid input");
                        }
                    })
                    .setNegativeButton("Cancel", null).show();
        });
    }

    private static byte[] parseNeedle(String s) {
        s = s.trim();
        // If it looks like hex bytes
        String cleaned = s.replace(" ", "").replace("0x", "").replace("0X", "");
        if (cleaned.matches("[0-9A-Fa-f]+") && cleaned.length() % 2 == 0) {
            try {
                byte[] out = new byte[cleaned.length() / 2];
                for (int i = 0; i < out.length; i++) {
                    out[i] = (byte) Integer.parseInt(cleaned.substring(i * 2, i * 2 + 2), 16);
                }
                return out;
            } catch (Exception ignored) { }
        }
        // fallback: ASCII
        return s.getBytes();
    }

    private static long searchInFile(File f, byte[] needle, long start) {
        try {
            RandomAccessFile raf = new RandomAccessFile(f, "r");
            try {
                long len = raf.length();
                byte[] buf = new byte[65536 + needle.length];
                long pos = start;
                while (pos < len) {
                    int read = (int) Math.min(65536 + needle.length, len - pos);
                    raf.seek(pos);
                    raf.readFully(buf, 0, read);
                    for (int i = 0; i + needle.length <= read; i++) {
                        boolean match = true;
                        for (int j = 0; j < needle.length; j++) {
                            if (buf[i + j] != needle[j]) { match = false; break; }
                        }
                        if (match) return pos + i;
                    }
                    pos += read - needle.length + 1;
                    if (read < 65536 + needle.length) break;
                }
            } finally {
                raf.close();
            }
        } catch (Exception ignored) { }
        return -1;
    }
}