package com.protorina.file;

import android.text.Editable;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small regex-based syntax coloring for common file types. */
public class Highlighter {
    private static final String CKW = "abstract|as|async|await|boolean|break|byte|case|catch|char|class|const|continue|"
            + "default|do|double|else|enum|export|extends|false|final|finally|float|for|fun|function|if|implements|"
            + "import|in|instanceof|int|interface|let|long|new|null|object|override|package|private|protected|public|"
            + "return|short|static|struct|super|switch|this|throw|throws|true|try|typeof|undefined|val|var|void|while";
    private static final String PYKW = "and|as|assert|break|class|continue|def|del|elif|else|except|False|finally|for|"
            + "from|global|if|import|in|is|lambda|None|nonlocal|not|or|pass|raise|return|True|try|while|with|yield";
    private static final String SHKW = "if|then|else|elif|fi|for|while|do|done|case|esac|function|in|echo|export|local|return|exit";
    private static final String STR = "\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'";
    private static final String NUM = "\\b\\d+(?:\\.\\d+)?\\b";

    private static Pattern build(String comment, String kw) {
        return Pattern.compile("(" + comment + ")|(" + STR + ")|(" + NUM + ")|(\\b(?:" + kw + ")\\b)");
    }

    private static final Pattern CLIKE = build("//[^\\n]*|/\\*[\\s\\S]*?\\*/", CKW);
    private static final Pattern HASH = build("#[^\\n]*", PYKW);
    private static final Pattern SHELL = build("#[^\\n]*", SHKW);
    private static final Pattern JSON = build("(?!)", "true|false|null");
    private static final Pattern MARKUP = Pattern.compile("(<!--[\\s\\S]*?-->)|(" + STR + ")|(\\b\\d+\\b)|(</?[A-Za-z][\\w:-]*)");

    private static boolean in(String ext, String list) {
        return ext.length() > 0 && ("," + list + ",").contains("," + ext + ",");
    }

    public static void apply(Editable e, String ext) {
        if (e.length() > 300000) return;
        Pattern p = null;
        if (in(ext, "js,mjs,ts,jsx,tsx,java,kt,c,cpp,h,hpp,cs,go,rs,php,swift,css,gradle,smali,vue,lua")) p = CLIKE;
        else if (in(ext, "py,rb,yml,yaml,toml,ini,conf,cfg,properties,env")) p = HASH;
        else if (in(ext, "sh,bat")) p = SHELL;
        else if ("json".equals(ext)) p = JSON;
        else if (in(ext, "xml,html,htm,svg")) p = MARKUP;
        ForegroundColorSpan[] old = e.getSpans(0, e.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan s : old) e.removeSpan(s);
        if (p == null) return;
        Matcher m = p.matcher(e);
        while (m.find()) {
            int color;
            if (m.group(1) != null) color = T.k3;
            else if (m.group(2) != null) color = T.k2;
            else if (m.group(3) != null) color = T.k4;
            else color = T.k1;
            e.setSpan(new ForegroundColorSpan(color), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }
}
