package com.protorina.file;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import java.io.File;

/**
 * Full-screen image viewer with pinch-to-zoom, pan and double-tap zoom.
 */
public class ImageViewer {

    public static void show(final Activity a, final File f) {
        final FrameLayout container = new FrameLayout(a);
        container.setBackgroundColor(0xFF000000);
        container.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        final ImageView iv = new ImageView(a);
        iv.setScaleType(ImageView.ScaleType.MATRIX);
        container.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        // Info bar at bottom
        final LinearLayout infoBar = new LinearLayout(a);
        infoBar.setOrientation(LinearLayout.HORIZONTAL);
        infoBar.setBackgroundColor(0xCC000000);
        infoBar.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
        infoBar.setGravity(Gravity.CENTER_VERTICAL);
        final TextView info = Ui.mono(a, "Loading…", 11, 0xFFFFFFFF);
        infoBar.addView(info, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView btnWall = Ui.text(a, "Wallpaper", 12, 0xFFFFFFFF, true);
        btnWall.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        infoBar.addView(btnWall);

        TextView btnShare = Ui.text(a, "Share", 12, 0xFFFFFFFF, true);
        btnShare.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
        infoBar.addView(btnShare);

        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        infoLp.gravity = Gravity.BOTTOM;
        container.addView(infoBar, infoLp);

        final android.app.AlertDialog dlg = Ui.dlg(a)
                .setView(container)
                .setNeutralButton("Close", null)
                .create();
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            dlg.getWindow().setBackgroundDrawableResource(android.R.color.black);
        }

        // Load bitmap in background
        new Thread(() -> {
            final Bitmap[] bmpHolder = new Bitmap[1];
            final String[] errHolder = new String[1];
            try {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                int w = opts.outWidth, h = opts.outHeight;
                // Decode with sampling if huge
                int sample = 1;
                int maxSide = 2400;
                while (w / sample > maxSide || h / sample > maxSide) sample *= 2;
                opts.inJustDecodeBounds = false;
                opts.inSampleSize = sample;
                bmpHolder[0] = BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                if (bmpHolder[0] == null) errHolder[0] = "Can't decode this image";
            } catch (Throwable t) {
                errHolder[0] = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            }
            a.runOnUiThread(() -> {
                if (errHolder[0] != null) {
                    info.setText("Error: " + errHolder[0]);
                    return;
                }
                final Bitmap bmp = bmpHolder[0];
                iv.setImageBitmap(bmp);
                info.setText(f.getName() + "  ·  " + bmp.getWidth() + "×" + bmp.getHeight()
                        + "  ·  " + Fs.human(f.length()));

                // Set up matrix for zoom/pan
                final Matrix matrix = new Matrix();
                final float[] values = new float[9];
                final PointF last = new PointF();
                final float[] lastDist = new float[1];
                final ScaleGestureDetector scaleDetector = new ScaleGestureDetector(a,
                        new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                            @Override
                            public boolean onScale(ScaleGestureDetector d) {
                                float factor = d.getScaleFactor();
                                matrix.postScale(factor, factor, d.getFocusX(), d.getFocusY());
                                iv.setImageMatrix(matrix);
                                return true;
                            }
                        });

                // Initial fit-center
                iv.post(() -> {
                    float vw = iv.getWidth(), vh = iv.getHeight();
                    float bw = bmp.getWidth(), bh = bmp.getHeight();
                    float scale = Math.min(vw / bw, vh / bh);
                    matrix.reset();
                    matrix.postScale(scale, scale);
                    matrix.postTranslate((vw - bw * scale) / 2f, (vh - bh * scale) / 2f);
                    iv.setImageMatrix(matrix);
                });

                final long[] lastTap = {0};
                iv.setOnTouchListener((v, ev) -> {
                    scaleDetector.onTouchEvent(ev);
                    switch (ev.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            last.set(ev.getX(), ev.getY());
                            long now = System.currentTimeMillis();
                            if (now - lastTap[0] < 300) {
                                // double tap → toggle zoom
                                matrix.getValues(values);
                                float cur = values[Matrix.MSCALE_X];
                                float target = cur < 2f ? cur * 2f : cur / 2f;
                                float factor = target / cur;
                                matrix.postScale(factor, factor, ev.getX(), ev.getY());
                                iv.setImageMatrix(matrix);
                            }
                            lastTap[0] = now;
                            break;
                        case MotionEvent.ACTION_MOVE:
                            if (ev.getPointerCount() == 1) {
                                float dx = ev.getX() - last.x;
                                float dy = ev.getY() - last.y;
                                matrix.postTranslate(dx, dy);
                                iv.setImageMatrix(matrix);
                                last.set(ev.getX(), ev.getY());
                            }
                            break;
                    }
                    return true;
                });

                btnShare.setOnClickListener(x -> Actions.openWith(a, f, true));
                btnWall.setOnClickListener(x -> {
                    try {
                        WallpaperManager wm = WallpaperManager.getInstance(a);
                        if (Build.VERSION.SDK_INT >= 24) {
                            wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM);
                        } else {
                            wm.setBitmap(bmp);
                        }
                        Ui.toast(a, "Wallpaper set");
                    } catch (Exception e) {
                        Ui.toast(a, "Couldn't set wallpaper: " + e.getMessage());
                    }
                });
            });
        }).start();
    }
}