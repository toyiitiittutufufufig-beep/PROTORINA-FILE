package com.protorina.file;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;

public class MainActivity extends Activity {
    private FilesView files;
    private EditorView editor;
    private TerminalView terminal;
    private ToolsView tools;
    private View[] tabs;
    private TextView[] labels;
    private ImageView[] icons;
    private int cur = 0;
    private boolean built = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        T.load(this);
        if (Fs.hasAllFiles(this)) build();
        else gate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!built && Fs.hasAllFiles(this)) build();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (!built && Fs.hasAllFiles(this)) build();
    }

    private void style() {
        getWindow().setStatusBarColor(T.bg);
        getWindow().setNavigationBarColor(T.sf);
        int f = getWindow().getDecorView().getSystemUiVisibility();
        if (T.dark) f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        else f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    private void gate() {
        style();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(T.bg);
        int p = Ui.dp(this, 32);
        root.setPadding(p, p, p, p);
        TextView t = Ui.text(this, "PROTORINA FILE", 24, T.tx, true);
        t.setGravity(Gravity.CENTER);
        root.addView(t);
        TextView s = Ui.text(this, "To browse and edit your files the app needs access to all files on this device.", 14, T.mu, false);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 24));
        root.addView(s);
        TextView btn = Ui.button(this, "Allow access", true);
        root.addView(btn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(v -> askPermission());
        setContentView(root);
    }

    private void askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[] {android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
    }

    private void build() {
        built = true;
        style();
        files = new FilesView(this);
        editor = new EditorView(this);
        terminal = new TerminalView(this);
        tools = new ToolsView(this);
        tabs = new View[] {files, editor, terminal, tools};

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(T.bg);
        FrameLayout content = new FrameLayout(this);
        for (View v : tabs) content.addView(v, new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(Ui.divider(this));

        LinearLayout nav = new LinearLayout(this);
        nav.setBackgroundColor(T.sf);
        nav.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4));
        String[] names = {"Files", "Editor", "Terminal", "Tools"};
        int[] res = {R.drawable.ic_folder, R.drawable.ic_pen, R.drawable.ic_term, R.drawable.ic_tools};
        labels = new TextView[4];
        icons = new ImageView[4];
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            icons[i] = Ui.icon(this, res[i], T.mu, 0);
            labels[i] = Ui.text(this, names[i], 11, T.mu, true);
            item.addView(icons[i], new LinearLayout.LayoutParams(Ui.dp(this, 24), Ui.dp(this, 24)));
            item.addView(labels[i]);
            item.setOnClickListener(v -> select(idx));
            nav.addView(item, new LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1f));
        }
        root.addView(nav);
        setContentView(root);
        select(0);
    }

    private void select(int i) {
        cur = i;
        for (int k = 0; k < 4; k++) {
            tabs[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            icons[k].setColorFilter(k == i ? T.ac : T.mu);
            labels[k].setTextColor(k == i ? T.ac : T.mu);
        }
    }

    public void openInEditor(File f) {
        editor.open(f);
        select(1);
    }

    public void toggleTheme() {
        if (editor != null && editor.hasUnsaved()) {
            Ui.toast(this, "Save your open files first");
            return;
        }
        T.set(this, !T.dark);
        build();
    }

    @Override
    public void onBackPressed() {
        if (!built) {
            super.onBackPressed();
            return;
        }
        if (cur == 0 && files.back()) return;
        if (cur != 0) {
            select(0);
            return;
        }
        super.onBackPressed();
    }
}
