package com.protorina.file;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Simple in-app file / folder chooser. mode: 0 = file, 1 = folder, 2 = file or folder. */
public class Pick {
    private final Activity act;
    private final int mode;
    private final Ui.Cb<File> cb;
    private File dir;
    private Dialog dialog;
    private TextView path;
    private ListView list;
    private final List<File> rows = new ArrayList<File>();

    public static void show(Activity a, File start, int mode, String title, Ui.Cb<File> cb) {
        new Pick(a, start, mode, title, cb);
    }

    private Pick(Activity a, File start, int mode, String title, Ui.Cb<File> cb) {
        this.act = a;
        this.mode = mode;
        this.cb = cb;
        this.dir = start != null && start.isDirectory() ? start : Environment.getExternalStorageDirectory();

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(T.sf);
        TextView t = Ui.text(a, title, 16, T.tx, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(a, 14), 0, Ui.dp(a, 6));
        root.addView(t);
        path = Ui.mono(a, "", 12, T.mu);
        path.setPadding(Ui.dp(a, 16), 0, Ui.dp(a, 16), Ui.dp(a, 8));
        path.setSingleLine(true);
        path.setEllipsize(android.text.TextUtils.TruncateAt.START);
        root.addView(path);
        root.addView(Ui.divider(a));
        list = new ListView(a);
        list.setDivider(null);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (mode != 0) {
            TextView sel = Ui.button(a, mode == 1 ? "Select this folder" : "Select this folder (or tap a file)", true);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 12));
            sel.setOnClickListener(v -> {
                dialog.dismiss();
                Pick.this.cb.done(dir);
            });
            root.addView(sel, lp);
        }
        dialog = Ui.sheet(a, root, 520);
        list.setOnItemClickListener((p, v, pos, id) -> {
            File f = rows.get(pos);
            if (f == null) {
                File up = dir.getParentFile();
                if (up != null) { dir = up; load(); }
            } else if (f.isDirectory()) {
                dir = f;
                load();
            } else {
                dialog.dismiss();
                Pick.this.cb.done(f);
            }
        });
        load();
    }

    private void load() {
        path.setText(dir.getAbsolutePath());
        rows.clear();
        if (dir.getParentFile() != null) rows.add(null);
        File[] fs = dir.listFiles();
        if (fs != null) {
            List<File> l = new ArrayList<File>(Arrays.asList(fs));
            Collections.sort(l, (a, b) -> {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
            for (File f : l) if (f.isDirectory() || mode != 1) rows.add(f);
        }
        list.setAdapter(new ArrayAdapter<File>(act, 0, rows) {
            @Override
            public View getView(int pos, View convert, ViewGroup parent) {
                File f = rows.get(pos);
                Context c = getContext();
                String label = f == null ? "..  (parent folder)" : (f.isDirectory() ? "[ " + f.getName() + " ]" : f.getName());
                TextView tv = Ui.text(c, label, 14, f == null || f.isDirectory() ? T.ac : T.tx, f == null || f.isDirectory());
                tv.setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 12));
                return tv;
            }
        });
    }
}
