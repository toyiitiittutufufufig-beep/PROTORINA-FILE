package com.protorina.file;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * Recycle Bin — deleted files go here, can be restored or purged.
 * Each deleted item gets a folder:  <bin>/<timestamp>_<name>/
 *     original.txt    (the actual file or folder)
 *     meta.txt        (original path + delete time)
 */
public class Recycle {

    private static final long EXPIRE_MS = 30L * 24 * 60 * 60 * 1000; // 30 days

    public static File binDir(Context c) {
        File ext = c.getExternalFilesDir(null);
        File base = ext != null ? ext : c.getFilesDir();
        File bin = new File(base, ".recycle_bin");
        if (!bin.exists()) bin.mkdirs();
        return bin;
    }

    /** Moves a file/folder to the bin. Returns true on success. */
    public static boolean move(File f, Context c) {
        try {
            File bin = binDir(c);
            long ts = System.currentTimeMillis();
            String safeName = f.getName().replaceAll("[\\\\/:*?\"<>|]", "_");
            File slot = new File(bin, ts + "_" + safeName);
            int n = 1;
            while (slot.exists()) {
                slot = new File(bin, ts + "_" + n + "_" + safeName);
                n++;
            }
            if (!slot.mkdirs()) return false;

            File target = new File(slot, f.getName());
            if (!f.renameTo(target)) {
                // cross-volume move: copy + delete
                Fs.copy(f, target);
                Fs.delete(f);
            }

            Properties p = new Properties();
            p.setProperty("original", f.getAbsolutePath());
            p.setProperty("deleted_at", String.valueOf(ts));
            FileOutputStream fos = new FileOutputStream(new File(slot, "meta.txt"));
            try {
                p.store(fos, null);
            } finally {
                fos.close();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Restores a bin slot to its original location. */
    public static boolean restore(File slot, Context c) {
        try {
            Properties p = new Properties();
            File metaFile = new File(slot, "meta.txt");
            if (!metaFile.exists()) return false;
            FileInputStream fis = new FileInputStream(metaFile);
            try {
                p.load(fis);
            } finally {
                fis.close();
            }
            String origPath = p.getProperty("original");
            if (origPath == null) return false;
            File orig = new File(origPath);
            File parent = orig.getParentFile();
            if (parent == null) return false;
            if (!parent.exists()) parent.mkdirs();

            // find the actual content inside the slot
            File[] kids = slot.listFiles();
            File content = null;
            if (kids != null) {
                for (File k : kids) if (!k.getName().equals("meta.txt")) { content = k; break; }
            }
            if (content == null) return false;

            File target = Fs.unique(parent, content.getName());
            if (!content.renameTo(target)) {
                Fs.copy(content, target);
                Fs.delete(content);
            }
            // remove slot
            Fs.delete(slot);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Permanently deletes a bin slot. */
    public static void purge(File slot) {
        try {
            Fs.delete(slot);
        } catch (IOException ignored) { }
    }

    /** Removes slots older than 30 days. */
    public static void autoClean(Context c) {
        File bin = binDir(c);
        File[] kids = bin.listFiles();
        if (kids == null) return;
        long now = System.currentTimeMillis();
        for (File k : kids) {
            if (!k.isDirectory()) continue;
            String name = k.getName();
            int u = name.indexOf('_');
            if (u <= 0) continue;
            try {
                long ts = Long.parseLong(name.substring(0, u));
                if (now - ts > EXPIRE_MS) purge(k);
            } catch (NumberFormatException ignored) { }
        }
    }

    /** Returns list of bin slots (newest first). */
    public static List<File> list(Context c) {
        File bin = binDir(c);
        File[] kids = bin.listFiles();
        List<File> out = new ArrayList<>();
        if (kids == null) return out;
        for (File k : kids) if (k.isDirectory()) out.add(k);
        Collections.sort(out, (a, b) -> b.getName().compareTo(a.getName()));
        return out;
    }

    /** Gets the original path recorded for a slot. */
    public static String originalPath(File slot) {
        try {
            Properties p = new Properties();
            FileInputStream fis = new FileInputStream(new File(slot, "meta.txt"));
            try {
                p.load(fis);
            } finally {
                fis.close();
            }
            return p.getProperty("original");
        } catch (Exception e) {
            return slot.getName();
        }
    }

    /** Gets the content file inside a slot. */
    public static File content(File slot) {
        File[] kids = slot.listFiles();
        if (kids != null) {
            for (File k : kids) if (!k.getName().equals("meta.txt")) return k;
        }
        return slot;
    }

    // ------------------------------------------------------------------ UI

    public static void show(final Activity a) {
        autoClean(a);

        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8), Ui.dp(a, 8));

        ScrollView sv = new ScrollView(a);
        sv.addView(root);

        final List<File> slots = list(a);

        if (slots.isEmpty()) {
            TextView empty = Ui.text(a, "Recycle bin is empty", 14, T.mu, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, Ui.dp(a, 40), 0, Ui.dp(a, 40));
            root.addView(empty);
        } else {
            final SimpleDateFormat df = new SimpleDateFormat("MMM d, HH:mm", Locale.getDefault());
            for (final File slot : slots) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 12), Ui.dp(a, 10));
                row.setBackground(Ui.shape(a, T.sf, 10, T.bd));

                File c = content(slot);
                String original = originalPath(slot);
                long ts = slot.lastModified();
                String nameStr = c.getName();
                String subStr = (c.isDirectory() ? "Folder" : Fs.human(c.length()))
                        + " · deleted " + df.format(new Date(ts));
                String pathStr = "from: " + original;

                TextView name = Ui.text(a, nameStr, 14, T.tx, true);
                TextView sub = Ui.text(a, subStr, 11, T.mu, false);
                TextView path = Ui.mono(a, pathStr, 10, T.mu);
                path.setSingleLine(true);
                path.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                row.addView(name);
                row.addView(sub);
                row.addView(path);

                LinearLayout actions = new LinearLayout(a);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                actions.setPadding(0, Ui.dp(a, 6), 0, 0);

                TextView restore = Ui.text(a, "Restore", 12, T.ac, true);
                restore.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
                restore.setBackground(Ui.shape(a, T.ib, 8, 0));
                restore.setOnClickListener(v -> {
                    if (Recycle.restore(slot, a)) {
                        Ui.toast(a, "Restored");
                        show(a); // refresh
                    } else {
                        Ui.toast(a, "Couldn't restore");
                    }
                });

                TextView purge = Ui.text(a, "Delete forever", 12, T.ac2, true);
                purge.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
                purge.setBackground(Ui.shape(a, T.ib, 8, 0));
                purge.setOnClickListener(v -> Ui.confirm(a,
                        "Delete \"" + nameStr + "\" permanently?",
                        "Delete", () -> {
                            Recycle.purge(slot);
                            show(a);
                        }));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.rightMargin = Ui.dp(a, 8);

                actions.addView(restore, lp);
                actions.addView(purge);
                row.addView(actions);

                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                rowLp.setMargins(0, Ui.dp(a, 4), 0, Ui.dp(a, 4));
                root.addView(row, rowLp);
            }
        }

        final android.app.AlertDialog dlg = Ui.dlg(a)
                .setTitle("Recycle bin (" + slots.size() + ")")
                .setView(sv)
                .setPositiveButton("Empty all", (d, w) -> {
                    Ui.confirm(a, "Empty the recycle bin?", "Empty", () -> {
                        for (File s : slots) Recycle.purge(s);
                        Ui.toast(a, "Recycle bin emptied");
                    });
                })
                .setNegativeButton("Close", null)
                .create();
        dlg.show();
    }
}