package com.protorina.file;

import android.content.Context;

/** Theme colors (dark / light), switched at runtime. */
public class T {
    public static boolean dark = true;
    public static int bg, sf, tx, mu, ac, ac2, bd, tn, ib, k1, k2, k3, k4, term, code, arch, img, apk, db;

    public static void load(Context c) {
        dark = c.getSharedPreferences("pf", Context.MODE_PRIVATE).getBoolean("dark", true);
        apply();
    }

    public static void set(Context c, boolean d) {
        dark = d;
        c.getSharedPreferences("pf", Context.MODE_PRIVATE).edit().putBoolean("dark", d).apply();
        apply();
    }

    private static void apply() {
        if (dark) {
            bg = 0xFF0E0E13; sf = 0xFF1A1A22; tx = 0xFFEDEDF2; mu = 0xFF9494A3;
            ac = 0xFFC084FC; ac2 = 0xFFF472B6; bd = 0xFF2A2A35; tn = 0xFF2B2140; ib = 0xFF24242E;
            k1 = 0xFFC084FC; k2 = 0xFF86EFAC; k3 = 0xFF7C7C8C; k4 = 0xFF7DD3FC; term = 0xFF08080B;
            code = 0xFF60A5FA; arch = 0xFFFBBF24; img = 0xFF34D399; apk = 0xFFA3E635; db = 0xFFFB923C;
        } else {
            bg = 0xFFF5F5FA; sf = 0xFFFFFFFF; tx = 0xFF1B1B22; mu = 0xFF62627A;
            ac = 0xFF7C3AED; ac2 = 0xFFDB2777; bd = 0xFFE2E2EC; tn = 0xFFEDE4FD; ib = 0xFFEEEEF5;
            k1 = 0xFF7C3AED; k2 = 0xFF047857; k3 = 0xFF6B6B7A; k4 = 0xFF0369A1; term = 0xFF14141B;
            code = 0xFF2563EB; arch = 0xFFB45309; img = 0xFF047857; apk = 0xFF4D7C0F; db = 0xFFC2410C;
        }
    }

    public static int kindColor(String kind) {
        if ("folder".equals(kind)) return ac;
        if ("code".equals(kind)) return code;
        if ("arch".equals(kind)) return arch;
        if ("img".equals(kind)) return img;
        if ("apk".equals(kind)) return apk;
        if ("db".equals(kind)) return db;
        return mu;
    }
}
