package com.protorina.file;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * A command line on top of Android's own shell (toybox: ls, cp, mv, cat, grep, sed, find, tar, ...).
 * Each command runs in its own process; `cd` is handled here so the folder sticks.
 * Full-screen programs (vim, top) need a real PTY and are not supported yet.
 */
public class TerminalView extends LinearLayout {
    private final MainActivity act;
    private final StringBuilder buf = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> history = new ArrayList<String>();
    private int hIdx = 0;
    private File cwd;
    private Process running;
    private boolean flushPending = false;
    private TextView out;
    private ScrollView sv;
    private EditText in;

    public TerminalView(MainActivity a) {
        super(a);
        act = a;
        setOrientation(VERTICAL);
        setBackgroundColor(T.bg);
        cwd = Environment.getExternalStorageDirectory();

        TextView title = Ui.text(a, "Terminal", 18, T.tx, true);
        title.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 8));
        addView(title);

        sv = new ScrollView(a);
        sv.setBackgroundColor(T.term);
        out = Ui.mono(a, "", 12, 0xFFD8D8E2);
        out.setTextIsSelectable(true);
        out.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 12), Ui.dp(a, 10));
        sv.addView(out);
        addView(sv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout keys = new LinearLayout(a);
        keys.setBackgroundColor(T.sf);
        keys.setPadding(Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 2));
        String[] k = {"TAB", "↑", "↓", "^C", "/", "-", "~"};
        for (final String s : k) {
            TextView b = Ui.mono(a, s, 13, T.tx);
            b.setGravity(Gravity.CENTER);
            b.setBackground(Ui.shape(a, T.ib, 10, 0));
            LayoutParams lp = new LayoutParams(0, Ui.dp(a, 42), 1f);
            lp.setMargins(Ui.dp(a, 3), 0, Ui.dp(a, 3), 0);
            b.setOnClickListener(v -> key(s));
            keys.addView(b, lp);
        }
        addView(keys);

        LinearLayout row = new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(T.sf);
        row.setPadding(Ui.dp(a, 12), 0, Ui.dp(a, 4), Ui.dp(a, 4));
        TextView pr = Ui.mono(a, "$", 14, T.ac2);
        row.addView(pr);
        in = new EditText(a);
        in.setBackground(null);
        in.setTypeface(android.graphics.Typeface.MONOSPACE);
        in.setTextSize(14);
        in.setTextColor(T.tx);
        in.setHint("command");
        in.setHintTextColor(T.mu);
        in.setSingleLine(true);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setPadding(Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12));
        row.addView(in, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView send = Ui.text(a, "Run", 14, T.ac, true);
        send.setPadding(Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12));
        row.addView(send);
        addView(row);

        in.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEND || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                submit();
                return true;
            }
            return false;
        });
        send.setOnClickListener(v -> submit());

        append("PROTORINA FILE terminal\nAndroid shell with toybox tools (ls, cp, mv, cat, grep, sed, find, tar...).\n"
                + "Type `help` for tips. Interactive programs (vim, top) aren't supported yet.\n\n");
        prompt();
    }

    private String shortCwd() {
        String p = cwd.getAbsolutePath();
        String home = Environment.getExternalStorageDirectory().getAbsolutePath();
        if (p.equals(home)) return "~";
        if (p.startsWith(home + "/")) return "~" + p.substring(home.length());
        return p;
    }

    private void prompt() {
        append("protorina:" + shortCwd() + " $ ");
    }

    private void key(String s) {
        if (s.equals("TAB")) {
            complete();
        } else if (s.equals("↑")) {
            if (history.isEmpty()) return;
            hIdx = Math.max(0, hIdx - 1);
            in.setText(history.get(hIdx));
            in.setSelection(in.length());
        } else if (s.equals("↓")) {
            if (history.isEmpty()) return;
            hIdx = Math.min(history.size(), hIdx + 1);
            in.setText(hIdx >= history.size() ? "" : history.get(hIdx));
            in.setSelection(in.length());
        } else if (s.equals("^C")) {
            if (running != null) {
                running.destroy();
                append("^C\n");
            }
        } else {
            in.getText().insert(in.getSelectionStart() < 0 ? in.length() : in.getSelectionStart(), s);
        }
    }

    private void complete() {
        String t = in.getText().toString();
        int sp = t.lastIndexOf(' ') + 1;
        String word = t.substring(sp);
        File dir = cwd;
        String prefix = word;
        int sl = word.lastIndexOf('/');
        if (sl >= 0) {
            String d = word.substring(0, sl + 1);
            dir = d.startsWith("/") ? new File(d) : new File(cwd, d);
            prefix = word.substring(sl + 1);
        }
        File[] fs = dir.listFiles();
        if (fs == null) return;
        List<String> m = new ArrayList<String>();
        for (File f : fs) if (f.getName().startsWith(prefix)) m.add(f.getName() + (f.isDirectory() ? "/" : ""));
        if (m.isEmpty()) return;
        String common = m.get(0);
        for (String s : m) {
            int i = 0;
            while (i < common.length() && i < s.length() && common.charAt(i) == s.charAt(i)) i++;
            common = common.substring(0, i);
        }
        String base = sl >= 0 ? word.substring(0, sl + 1) : "";
        in.setText(t.substring(0, sp) + base + common);
        in.setSelection(in.length());
        if (m.size() > 1) append("\n" + android.text.TextUtils.join("  ", m) + "\n");
    }

    private void submit() {
        final String cmd = in.getText().toString().trim();
        in.setText("");
        if (running != null) {
            append("(a command is still running, press ^C to stop it)\n");
            return;
        }
        append(cmd + "\n");
        if (cmd.length() == 0) {
            prompt();
            return;
        }
        history.add(cmd);
        hIdx = history.size();
        if (cmd.equals("clear")) {
            buf.setLength(0);
            prompt();
            flush();
            return;
        }
        if (cmd.equals("help")) {
            append("cd <dir>     change folder (cd, cd .., cd ~, cd /sdcard)\n"
                    + "clear        clear the screen\n"
                    + "TAB          complete file names\n"
                    + "^C           stop the running command\n"
                    + "Anything else runs in the Android shell, e.g.  ls -la | grep txt\n");
            prompt();
            return;
        }
        if (cmd.equals("cd") || cmd.startsWith("cd ")) {
            cd(cmd.length() > 2 ? cmd.substring(3).trim() : "~");
            prompt();
            return;
        }
        run(cmd);
    }

    private void cd(String arg) {
        String home = Environment.getExternalStorageDirectory().getAbsolutePath();
        if (arg.startsWith("\"") && arg.endsWith("\"") && arg.length() > 1) arg = arg.substring(1, arg.length() - 1);
        File t;
        if (arg.equals("~") || arg.length() == 0) t = new File(home);
        else if (arg.startsWith("~/")) t = new File(home, arg.substring(2));
        else if (arg.startsWith("/")) t = new File(arg);
        else t = new File(cwd, arg);
        try {
            t = t.getCanonicalFile();
        } catch (Exception e) {
            // keep as is
        }
        if (t.isDirectory()) cwd = t;
        else append("cd: " + arg + ": no such folder\n");
    }

    private void run(final String cmd) {
        try {
            ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", cmd);
            pb.directory(cwd);
            pb.redirectErrorStream(true);
            Map<String, String> env = pb.environment();
            env.put("HOME", Environment.getExternalStorageDirectory().getAbsolutePath());
            env.put("TERM", "dumb");
            running = pb.start();
        } catch (Exception e) {
            append("error: " + e.getMessage() + "\n");
            prompt();
            return;
        }
        final Process p = running;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStreamReader r = new InputStreamReader(p.getInputStream(), "UTF-8");
                    char[] c = new char[2048];
                    int n;
                    while ((n = r.read(c)) > 0) {
                        final String s = new String(c, 0, n);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                append(s);
                            }
                        });
                    }
                } catch (Exception e) {
                    // process ended or was killed
                }
                int code = -1;
                try {
                    code = p.waitFor();
                } catch (InterruptedException e) {
                    // ignore
                }
                final int fc = code;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        running = null;
                        if (fc != 0) append("[exit " + fc + "]\n");
                        prompt();
                    }
                });
            }
        }).start();
    }

    private void append(String s) {
        buf.append(s.replaceAll("\u001B\\[[0-9;?]*[A-Za-z]", "").replace("\r", ""));
        if (buf.length() > 120000) buf.delete(0, 20000);
        if (!flushPending) {
            flushPending = true;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    flush();
                }
            }, 60);
        }
    }

    private void flush() {
        flushPending = false;
        out.setText(buf.toString());
        sv.post(new Runnable() {
            @Override
            public void run() {
                sv.fullScroll(android.view.View.FOCUS_DOWN);
            }
        });
    }
}
