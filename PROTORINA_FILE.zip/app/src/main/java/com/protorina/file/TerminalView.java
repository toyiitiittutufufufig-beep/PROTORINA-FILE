package com.protorina.file;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Command interpreter for file operations.
 * Built on top of Fs.java — no shell, no root, no external libraries.
 * Supports: ls, cd, pwd, cat, echo, rm, cp, mv, mkdir, touch,
 *           find, grep, edit, info, clear, help, tree, open
 * Supports: >, >>, |, *, ?
 */
public class TerminalView extends LinearLayout {
    private final MainActivity act;
    private final StringBuilder buf = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> history = new ArrayList<>();
    private int hIdx = 0;
    private File cwd;
    private boolean flushPending = false;
    private TextView out;
    private ScrollView sv;
    private EditText in;

    public TerminalView(MainActivity a) {
        super(a);
        act = a;
        setOrientation(VERTICAL);
        setBackgroundColor(T.bg);
        cwd = Environment.getExternalStorageDirectory();

        TextView title = Ui.text(a, "Terminal", 18, T.tx, true);
        title.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 8));
        addView(title);

        sv = new ScrollView(a);
        sv.setBackgroundColor(T.term);
        out = Ui.mono(a, "", 12, 0xFFD8D8E2);
        out.setTextIsSelectable(true);
        out.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 12), Ui.dp(a, 10));
        sv.addView(out);
        addView(sv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout keys = new LinearLayout(a);
        keys.setBackgroundColor(T.sf);
        keys.setPadding(Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 2));
        String[] k = {"TAB", "↑", "↓", "clear", "/", "-", "~"};
        for (final String s : k) {
            TextView b = Ui.mono(a, s, 13, T.tx);
            b.setGravity(Gravity.CENTER);
            b.setBackground(Ui.shape(a, T.ib, 10, 0));
            LayoutParams lp = new LayoutParams(0, Ui.dp(a, 42), 1f);
            lp.setMargins(Ui.dp(a, 3), 0, Ui.dp(a, 3), 0);
            b.setOnClickListener(v -> key(s));
            keys.addView(b, lp);
        }
        addView(keys);

        LinearLayout row = new LinearLayout(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(T.sf);
        row.setPadding(Ui.dp(a, 12), 0, Ui.dp(a, 4), Ui.dp(a, 4));
        TextView pr = Ui.mono(a, "$", 14, T.ac2);
        row.addView(pr);
        in = new EditText(a);
        in.setBackground(null);
        in.setTypeface(android.graphics.Typeface.MONOSPACE);
        in.setTextSize(14);
        in.setTextColor(T.tx);
        in.setHint("command");
        in.setHintTextColor(T.mu);
        in.setSingleLine(true);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setPadding(Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12));
        row.addView(in, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView send = Ui.text(a, "Run", 14, T.ac, true);
        send.setPadding(Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12));
        row.addView(send);
        addView(row);

        in.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEND || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                submit();
                return true;
            }
            return false;
        });
        send.setOnClickListener(v -> submit());

        append("PROTORINA FILE terminal\nType `help` for available commands.\n\n");
        prompt();
    }

    private String shortCwd() {
        String p = cwd.getAbsolutePath();
        String home = Environment.getExternalStorageDirectory().getAbsolutePath();
        if (p.equals(home)) return "~";
        if (p.startsWith(home + "/")) return "~" + p.substring(home.length());
        return p;
    }

    private void prompt() {
        append("protorina:" + shortCwd() + " $ ");
    }

    private void key(String s) {
        if (s.equals("TAB")) {
            complete();
        } else if (s.equals("↑")) {
            if (history.isEmpty()) return;
            hIdx = Math.max(0, hIdx - 1);
            in.setText(history.get(hIdx));
            in.setSelection(in.length());
        } else if (s.equals("↓")) {
            if (history.isEmpty()) return;
            hIdx = Math.min(history.size(), hIdx + 1);
            in.setText(hIdx >= history.size() ? "" : history.get(hIdx));
            in.setSelection(in.length());
        } else if (s.equals("clear")) {
            buf.setLength(0);
            prompt();
            flush();
        } else {
            int sel = in.getSelectionStart();
            if (sel < 0) sel = in.length();
            in.getText().insert(sel, s);
        }
    }

    private void complete() {
        String t = in.getText().toString();
        int sp = t.lastIndexOf(' ') + 1;
        String word = t.substring(sp);
        File dir = cwd;
        String prefix = word;
        int sl = word.lastIndexOf('/');
        if (sl >= 0) {
            String d = word.substring(0, sl + 1);
            dir = d.startsWith("/") ? new File(d) : new File(cwd, d);
            prefix = word.substring(sl + 1);
        }
        File[] fs = dir.listFiles();
        if (fs == null) return;
        List<String> m = new ArrayList<>();
        for (File f : fs) if (f.getName().startsWith(prefix)) m.add(f.getName() + (f.isDirectory() ? "/" : ""));
        if (m.isEmpty()) return;
        String common = m.get(0);
        for (String s : m) {
            int i = 0;
            while (i < common.length() && i < s.length() && common.charAt(i) == s.charAt(i)) i++;
            common = common.substring(0, i);
        }
        String base = sl >= 0 ? word.substring(0, sl + 1) : "";
        in.setText(t.substring(0, sp) + base + common);
        in.setSelection(in.length());
        if (m.size() > 1) append("\n" + android.text.TextUtils.join("  ", m) + "\n");
    }

    private void submit() {
        String cmd = in.getText().toString().trim();
        in.setText("");
        if (cmd.length() == 0) {
            prompt();
            return;
        }
        append(cmd + "\n");
        history.add(cmd);
        hIdx = history.size();
        try {
            runLine(cmd);
        } catch (Exception e) {
            append("error: " + e.getMessage() + "\n");
        }
        prompt();
    }

    // ============================================================== PARSER

    private void runLine(String line) {
        // Split by pipe (|) for chaining
        List<String> pipeParts = splitRespectQuotes(line, '|');
        String pipedInput = null;
        for (int i = 0; i < pipeParts.size(); i++) {
            String part = pipeParts.get(i).trim();
            String output = execOne(part, pipedInput);
            if (output == null) output = "";
            pipedInput = output;
        }
        if (pipedInput != null && !pipedInput.isEmpty()) {
            append(pipedInput);
            if (!pipedInput.endsWith("\n")) append("\n");
        }
    }

    /** Runs a single command (no pipes), returns its stdout as String (or null). */
    private String execOne(String raw, String pipedInput) {
        // Handle output redirection: > or >>
        boolean appendMode = false;
        String outFile = null;
        String cmd = raw;
        int idx = findRedirect(cmd);
        if (idx >= 0) {
            String op = cmd.substring(idx, idx + 1);
            appendMode = cmd.charAt(idx) == '>' && idx + 1 < cmd.length() && cmd.charAt(idx + 1) == '>';
            int start = idx + (appendMode ? 2 : 1);
            outFile = cmd.substring(start).trim();
            cmd = cmd.substring(0, idx).trim();
        }

        String result = execCommand(cmd, pipedInput);

        if (outFile != null) {
            try {
                File f = resolve(outFile);
                if (!appendMode) {
                    Fs.writeText(f, result == null ? "" : result);
                } else {
                    String old = f.exists() ? Fs.readText(f, Integer.MAX_VALUE) : "";
                    Fs.writeText(f, old + (result == null ? "" : result));
                }
                return null;
            } catch (Exception e) {
                return "error writing file: " + e.getMessage() + "\n";
            }
        }
        return result;
    }

    private int findRedirect(String s) {
        boolean inQuote = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\'') inQuote = !inQuote;
            if (!inQuote && c == '>') return i;
        }
        return -1;
    }

    // ============================================================== COMMANDS

    private String execCommand(String cmd, String pipedInput) {
        if (cmd.length() == 0) return pipedInput;
        List<String> parts = splitRespectQuotes(cmd, ' ');
        if (parts.isEmpty()) return pipedInput;
        String name = parts.get(0).toLowerCase(Locale.ROOT);
        List<String> args = new ArrayList<>(parts.subList(1, parts.size()));

        switch (name) {
            case "help":     return cmdHelp();
            case "pwd":      return cwd.getAbsolutePath() + "\n";
            case "ls":
            case "dir":      return cmdLs(args);
            case "tree":     return cmdTree(args);
            case "cd":       return cmdCd(args);
            case "cat":      return cmdCat(args, pipedInput);
            case "echo":     return cmdEcho(args);
            case "touch":    return cmdTouch(args);
            case "mkdir":    return cmdMkdir(args);
            case "rm":       return cmdRm(args);
            case "cp":       return cmdCp(args, false);
            case "mv":       return cmdCp(args, true);
            case "find":     return cmdFind(args);
            case "grep":     return cmdGrep(args, pipedInput);
            case "info":     return cmdInfo(args);
            case "edit":     return cmdEdit(args);
            case "open":     return cmdOpen(args);
            case "clear":    buf.setLength(0); return null;
            default:
                return "unknown command: " + name + "\nType `help` for the list.\n";
        }
    }

    private String cmdHelp() {
        return "Available commands:\n"
                + "  ls [path]           list files\n"
                + "  tree [path]         show folder tree\n"
                + "  cd <path>           change directory\n"
                + "  pwd                 show current directory\n"
                + "  cat <file>          print file content\n"
                + "  echo <text> > file  write text to file (>> to append)\n"
                + "  touch <file>        create empty file\n"
                + "  mkdir <dir>         create folder\n"
                + "  rm [-r] <path>      delete file or folder\n"
                + "  cp <src> <dst>      copy\n"
                + "  mv <src> <dst>      move / rename\n"
                + "  find [path] -name <pattern>\n"
                + "  grep <text> <file>  search inside a file\n"
                + "  info <file>         show file details\n"
                + "  edit <file>         open file in text editor\n"
                + "  open <file>         open file with system app\n"
                + "  clear               clear the screen\n"
                + "\nFeatures: >, >>, |, * and ? wildcards, TAB completion.\n";
    }

    private String cmdLs(List<String> args) {
        File dir = cwd;
        List<File> targets = new ArrayList<>();
        if (args.isEmpty()) {
            targets.add(dir);
        } else {
            for (String a : args) {
                if (a.startsWith("-")) continue;
                File[] m = expand(a);
                if (m.length == 0) {
                    targets.add(resolve(a));
                } else {
                    Collections.addAll(targets, m);
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        for (File f : targets) {
            if (f.isDirectory()) {
                sb.append(f.getName().equals("") ? "/" : f.getName()).append("/:\n");
                File[] kids = f.listFiles();
                if (kids == null) {
                    sb.append("  (no access)\n");
                } else {
                    List<File> list = new ArrayList<>(Arrays.asList(kids));
                    Collections.sort(list, (a, b) -> {
                        if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                        return a.getName().compareToIgnoreCase(b.getName());
                    });
                    if (list.isEmpty()) sb.append("  (empty)\n");
                    for (File k : list) {
                        if (k.isDirectory()) sb.append("  [ ").append(k.getName()).append(" ]\n");
                        else sb.append("  ").append(k.getName())
                                .append("   ").append(Fs.human(k.length())).append("\n");
                    }
                }
            } else if (f.exists()) {
                sb.append(f.getName()).append("   ").append(Fs.human(f.length())).append("\n");
            } else {
                sb.append("ls: ").append(f.getPath()).append(": not found\n");
            }
        }
        return sb.toString();
    }

    private String cmdTree(List<String> args) {
        File start = args.isEmpty() ? cwd : resolve(args.get(0));
        StringBuilder sb = new StringBuilder();
        sb.append(start.getAbsolutePath()).append("\n");
        treeRec(start, "", sb, 0);
        return sb.toString();
    }

    private void treeRec(File dir, String prefix, StringBuilder sb, int depth) {
        if (depth > 6) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        List<File> list = new ArrayList<>(Arrays.asList(kids));
        Collections.sort(list, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (int i = 0; i < list.size(); i++) {
            File f = list.get(i);
            boolean last = i == list.size() - 1;
            sb.append(prefix).append(last ? "└── " : "├── ").append(f.getName()).append("\n");
            if (f.isDirectory()) treeRec(f, prefix + (last ? "    " : "│   "), sb, depth + 1);
        }
    }

    private String cmdCd(List<String> args) {
        if (args.isEmpty()) {
            cwd = Environment.getExternalStorageDirectory();
            return null;
        }
        File t = resolve(args.get(0));
        if (t.isDirectory()) {
            cwd = t;
        } else {
            return "cd: " + args.get(0) + ": not a folder\n";
        }
        return null;
    }

    private String cmdCat(List<String> args, String pipedInput) {
        if (args.isEmpty()) return pipedInput == null ? "cat: missing file\n" : pipedInput;
        StringBuilder sb = new StringBuilder();
        for (String a : args) {
            File[] m = expand(a);
            if (m.length == 0) m = new File[]{resolve(a)};
            for (File f : m) {
                try {
                    sb.append(Fs.readText(f, Integer.MAX_VALUE));
                    if (!sb.toString().endsWith("\n")) sb.append("\n");
                } catch (Exception e) {
                    sb.append("cat: ").append(f.getName()).append(": ").append(e.getMessage()).append("\n");
                }
            }
        }
        return sb.toString();
    }

    private String cmdEcho(List<String> args) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.size(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(unquote(args.get(i)));
        }
        return sb.toString() + "\n";
    }

    private String cmdTouch(List<String> args) {
        if (args.isEmpty()) return "touch: missing file name\n";
        StringBuilder sb = new StringBuilder();
        for (String a : args) {
            try {
                File f = resolve(a);
                if (!f.exists()) f.createNewFile();
            } catch (Exception e) {
                sb.append("touch: ").append(a).append(": ").append(e.getMessage()).append("\n");
            }
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private String cmdMkdir(List<String> args) {
        if (args.isEmpty()) return "mkdir: missing folder name\n";
        StringBuilder sb = new StringBuilder();
        for (String a : args) {
            if (a.startsWith("-")) continue;
            File f = resolve(a);
            if (!f.mkdirs() && !f.isDirectory()) sb.append("mkdir: can't create ").append(a).append("\n");
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private String cmdRm(List<String> args) {
        if (args.isEmpty()) return "rm: missing path\n";
        boolean recursive = false;
        List<String> targets = new ArrayList<>();
        for (String a : args) {
            if (a.equals("-r") || a.equals("-rf") || a.equals("-R")) recursive = true;
            else targets.add(a);
        }
        StringBuilder sb = new StringBuilder();
        for (String a : targets) {
            File[] m = expand(a);
            if (m.length == 0) m = new File[]{resolve(a)};
            for (File f : m) {
                if (!f.exists()) {
                    sb.append("rm: ").append(a).append(": not found\n");
                    continue;
                }
                if (f.isDirectory() && !recursive) {
                    sb.append("rm: ").append(a).append(": is a folder (use -r)\n");
                    continue;
                }
                try {
                    Fs.delete(f);
                } catch (Exception e) {
                    sb.append("rm: ").append(a).append(": ").append(e.getMessage()).append("\n");
                }
            }
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private String cmdCp(List<String> args, boolean move) {
        if (args.size() < 2) return (move ? "mv" : "cp") + ": needs source and target\n";
        File src = resolve(args.get(0));
        File dst = resolve(args.get(1));
        if (!src.exists()) return "source not found: " + args.get(0) + "\n";
        try {
            if (dst.isDirectory()) {
                if (move) Fs.move(src, dst);
                else Fs.copy(src, Fs.unique(dst, src.getName()));
            } else {
                if (move) {
                    if (!src.renameTo(dst)) {
                        Fs.copy(src, dst);
                        Fs.delete(src);
                    }
                } else {
                    Fs.copy(src, dst);
                }
            }
        } catch (Exception e) {
            return (move ? "mv" : "cp") + ": " + e.getMessage() + "\n";
        }
        return null;
    }

    private String cmdFind(List<String> args) {
        File start = cwd;
        String pattern = "*";
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (a.equals("-name") && i + 1 < args.size()) {
                pattern = args.get(++i);
            } else if (!a.startsWith("-")) {
                start = resolve(a);
            }
        }
        final String pat = pattern;
        List<String> hits = new ArrayList<>();
        findRec(start, pat, hits, 0);
        if (hits.isEmpty()) return "no matches\n";
        StringBuilder sb = new StringBuilder();
        for (String s : hits) sb.append(s).append("\n");
        return sb.toString();
    }

    private void findRec(File dir, String pat, List<String> hits, int depth) {
        if (depth > 8 || hits.size() > 500) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File f : kids) {
            if (wildMatch(pat, f.getName())) hits.add(f.getAbsolutePath());
            if (f.isDirectory()) findRec(f, pat, hits, depth + 1);
        }
    }

    private String cmdGrep(List<String> args, String pipedInput) {
        if (args.isEmpty()) return "grep: missing pattern\n";
        String pattern = unquote(args.get(0));
        StringBuilder sb = new StringBuilder();
        if (args.size() >= 2) {
            for (int i = 1; i < args.size(); i++) {
                File[] m = expand(args.get(i));
                if (m.length == 0) m = new File[]{resolve(args.get(i))};
                for (File f : m) {
                    try {
                        String text = Fs.readText(f, 5 * 1024 * 1024);
                        int lineNo = 0;
                        for (String line : text.split("\n")) {
                            lineNo++;
                            if (line.toLowerCase(Locale.ROOT).contains(pattern.toLowerCase(Locale.ROOT))) {
                                sb.append(f.getName()).append(":").append(lineNo).append(": ").append(line).append("\n");
                            }
                        }
                    } catch (Exception e) {
                        sb.append("grep: ").append(f.getName()).append(": ").append(e.getMessage()).append("\n");
                    }
                }
            }
        } else if (pipedInput != null) {
            int lineNo = 0;
            for (String line : pipedInput.split("\n")) {
                lineNo++;
                if (line.toLowerCase(Locale.ROOT).contains(pattern.toLowerCase(Locale.ROOT))) {
                    sb.append(line).append("\n");
                }
            }
        } else {
            return "grep: needs file or piped input\n";
        }
        return sb.toString();
    }

    private String cmdInfo(List<String> args) {
        if (args.isEmpty()) return "info: missing file\n";
        File f = resolve(args.get(0));
        if (!f.exists()) return "info: not found\n";
        return "Path: " + f.getAbsolutePath() + "\n"
                + "Type: " + (f.isDirectory() ? "Folder" : Fs.label(f)) + "\n"
                + "Size: " + (f.isDirectory() ? "-" : Fs.human(f.length())) + "\n"
                + "Modified: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new java.util.Date(f.lastModified())) + "\n"
                + "Readable: " + f.canRead() + "  Writable: " + f.canWrite() + "\n";
    }

    private String cmdEdit(List<String> args) {
        if (args.isEmpty()) return "edit: missing file\n";
        File f = resolve(args.get(0));
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (Exception e) {
                return "edit: can't create file\n";
            }
        }
        act.openInEditor(f);
        return "opening in editor: " + f.getName() + "\n";
    }

    private String cmdOpen(List<String> args) {
        if (args.isEmpty()) return "open: missing file\n";
        File f = resolve(args.get(0));
        if (!f.exists()) return "open: not found\n";
        Actions.openWith(act, f, false);
        return null;
    }

    // ============================================================== HELPERS

    /** Resolves a path relative to cwd, handles ~, and quotes. */
    private File resolve(String raw) {
        String path = unquote(raw);
        String home = Environment.getExternalStorageDirectory().getAbsolutePath();
        File f;
        if (path.equals("~")) f = new File(home);
        else if (path.startsWith("~/")) f = new File(home, path.substring(2));
        else if (path.startsWith("/")) f = new File(path);
        else f = new File(cwd, path);
        try {
            return f.getCanonicalFile();
        } catch (Exception e) {
            return f;
        }
    }

    private String unquote(String s) {
        if (s.length() >= 2) {
            char a = s.charAt(0);
            char b = s.charAt(s.length() - 1);
            if ((a == '"' && b == '"') || (a == '\'' && b == '\'')) {
                return s.substring(1, s.length() - 1);
            }
        }
        return s;
    }

    /** Expands wildcards in a path relative to cwd. */
    private File[] expand(String raw) {
        String path = unquote(raw);
        if (!path.contains("*") && !path.contains("?")) return new File[0];
        int slash = path.lastIndexOf('/');
        String dirPart = slash >= 0 ? path.substring(0, slash) : "";
        String patPart = slash >= 0 ? path.substring(slash + 1) : path;
        File dir = slash < 0 ? cwd : resolve(dirPart.length() == 0 ? "/" : dirPart);
        File[] kids = dir.listFiles();
        if (kids == null) return new File[0];
        List<File> hits = new ArrayList<>();
        for (File f : kids) {
            if (wildMatch(patPart, f.getName())) hits.add(f);
        }
        return hits.toArray(new File[0]);
    }

    private boolean wildMatch(String pat, String name) {
        StringBuilder re = new StringBuilder();
        for (char c : pat.toCharArray()) {
            if (c == '*') re.append(".*");
            else if (c == '?') re.append(".");
            else if ("\\.[]{}()+-^$|".indexOf(c) >= 0) re.append('\\').append(c);
            else re.append(c);
        }
        return name.matches("(?i)" + re);
    }

    /** Splits a string by a separator, respecting quotes. */
    private List<String> splitRespectQuotes(String s, char sep) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQ = false;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inQ) {
                if (c == q) inQ = false;
                else cur.append(c);
            } else if (c == '"' || c == '\'') {
                inQ = true;
                q = c;
                cur.append(c);
            } else if (c == sep) {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out;
    }

    // ============================================================== OUTPUT

    private void append(String s) {
        buf.append(s);
        if (buf.length() > 200000) buf.delete(0, 40000);
        if (!flushPending) {
            flushPending = true;
            handler.postDelayed(() -> flush(), 60);
        }
    }

    private void flush() {
        flushPending = false;
        out.setText(buf.toString());
        sv.post(() -> sv.fullScroll(android.view.View.FOCUS_DOWN));
    }
}