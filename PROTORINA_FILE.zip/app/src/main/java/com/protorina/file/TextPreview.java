package com.protorina.file;

import android.app.Activity;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

/**
 * Fast read-only text preview. Shows up to 30 MB with line numbers.
 */
public class TextPreview {

    private static final int MAX_PREVIEW = 30 * 1024 * 1024; // 30 MB

    public static void show(final Activity a, final File f) {
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 12);
        root.setPadding(p, p, p, p);

        TextView loading = Ui.text(a, "Loading…", 14, T.mu, false);
        loading.setGravity(Gravity.CENTER);
        root.addView(loading);

        final ScrollView sv = new ScrollView(a);
        sv.addView(root);

        final android.app.AlertDialog dlg = Ui.dlg(a)
                .setTitle(f.getName())
                .setView(sv)
                .setPositiveButton("Edit", (d, w) -> ((MainActivity) a).openInEditor(f))
                .setNeutralButton("Close", null)
                .create();
        dlg.show();

        new Thread(() -> {
            final StringBuilder content = new StringBuilder();
            final String[] err = {null};
            final long[] stats = new long[2]; // [size, lines]
            try {
                if (!Fs.isText(f)) {
                    err[0] = "This file doesn't look like text";
                } else {
                    String text = Fs.readText(f, MAX_PREVIEW);
                    stats[0] = f.length();
                    String[] lines = text.split("\n", -1);
                    stats[1] = lines.length;
                    int width = String.valueOf(lines.length).length();
                    if (width < 3) width = 3;
                    for (int i = 0; i < lines.length; i++) {
                        content.append(String.format(Locale.US, "%" + width + "d │ ", i + 1))
                                .append(lines[i]);
                        if (i < lines.length - 1) content.append("\n");
                    }
                    if (f.length() > MAX_PREVIEW) {
                        content.append("\n\n… (truncated, file is ")
                                .append(Fs.human(f.length())).append(")");
                    }
                }
            } catch (Throwable t) {
                err[0] = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
            }
            a.runOnUiThread(() -> {
                root.removeAllViews();
                if (err[0] != null) {
                    TextView e = Ui.text(a, err[0], 14, T.tx, false);
                    e.setTextIsSelectable(true);
                    e.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16));
                    root.addView(e);
                    return;
                }
                TextView info = Ui.mono(a,
                        Fs.human(stats[0]) + "  ·  " + stats[1] + " lines",
                        11, T.mu);
                info.setPadding(Ui.dp(a, 4), 0, Ui.dp(a, 4), Ui.dp(a, 8));
                root.addView(info);

                TextView tv = Ui.mono(a, content.toString(), 12, T.tx);
                tv.setTextIsSelectable(true);
                tv.setHorizontallyScrolling(true);
                tv.setPadding(Ui.dp(a, 4), Ui.dp(a, 4), Ui.dp(a, 4), Ui.dp(a, 4));
                root.addView(tv, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            });
        }).start();
    }
}