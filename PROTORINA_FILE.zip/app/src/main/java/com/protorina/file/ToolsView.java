package com.protorina.file;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

public class ToolsView extends LinearLayout {
    private final MainActivity act;

    public ToolsView(MainActivity a) {
        super(a);
        act = a;
        setOrientation(VERTICAL);
        setBackgroundColor(T.bg);
        TextView title = Ui.text(a, "Tools", 18, T.tx, true);
        title.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 8));
        addView(title);
        ScrollView sv = new ScrollView(a);
        LinearLayout grid = new LinearLayout(a);
        grid.setOrientation(VERTICAL);
        grid.setPadding(Ui.dp(a, 12), Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 12));
        sv.addView(grid);
        addView(sv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        card(grid, "Encrypt", "AES-256 with password", () -> pickFile("Encrypt which file?", f -> Actions.encrypt(act, f, null)));
        card(grid, "Decrypt", "Restore protected files", () -> pickFile("Decrypt which file?", f -> Actions.decrypt(act, f, null)));
        card(grid, "Compress", "zip, optional password", () -> Pick.show(act, null, 2, "Compress which file or folder?", f -> {
            java.util.List<File> l = new java.util.ArrayList<File>();
            l.add(f);
            Actions.compress(act, l, f.getParentFile(), null);
        }));
        card(grid, "Extract", "zip, with password", () -> pickFile("Extract which archive?", f -> Actions.extract(act, f, null)));
        card(grid, "Hash", "MD5, SHA-1, SHA-256", () -> pickFile("Hash which file?", f -> Actions.hash(act, f)));
        card(grid, "Base64", "Encode and decode text", () -> Actions.base64(act));
        card(grid, "Find in files", "Search text in folders", () -> Actions.findInFiles(act));

        card(grid, "APK Info", "View manifest, permissions, signature", () ->
                Pick.show(act, null, 0, "Pick an APK", f -> {
                    if (f.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) {
                        Actions.apkInfo(act, f);
                    } else {
                        Ui.toast(act, "That's not an APK file");
                    }
                }));

        card(grid, "Sign APK", "Sign with a keystore file", () ->
                Pick.show(act, null, 0, "Pick an APK to sign", f -> {
                    if (f.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) {
                        Actions.apkSign(act, f, null);
                    } else {
                        Ui.toast(act, "That's not an APK file");
                    }
                }));

        card(grid, "Text preview", "Quick read-only view of text files", () ->
                Pick.show(act, null, 0, "Pick a text file", f -> TextPreview.show(act, f)));

        card(grid, "Image viewer", "View image with zoom and pan", () ->
                Pick.show(act, null, 0, "Pick an image", f -> ImageViewer.show(act, f)));

        card(grid, "Recycle bin", "Restore recently deleted files", () -> Recycle.show(act));

        card(grid, "Hex editor", "View and edit any file byte by byte", () ->
                Pick.show(act, null, 0, "Pick a file", f -> HexViewer.show(act, f)));
    }

    private void pickFile(String title, Ui.Cb<File> cb) {
        Pick.show(act, null, 0, title, cb);
    }

    private void card(LinearLayout grid, String title, String sub, final Runnable r) {
        LinearLayout c = new LinearLayout(act);
        c.setOrientation(VERTICAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setBackground(Ui.shape(act, T.sf, 14, T.bd));
        c.setPadding(Ui.dp(act, 16), Ui.dp(act, 14), Ui.dp(act, 16), Ui.dp(act, 14));
        c.addView(Ui.text(act, title, 15, T.tx, true));
        c.addView(Ui.text(act, sub, 12, T.mu, false));
        c.setOnClickListener(v -> r.run());
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4));
        grid.addView(c, lp);
    }
}