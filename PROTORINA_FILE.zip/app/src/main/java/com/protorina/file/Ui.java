package com.protorina.file;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Ui {
    public interface Cb<V> {
        void done(V v);
    }

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable shape(Context c, int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView mono(Context c, String s, int sp, int color) {
        TextView t = text(c, s, sp, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    public static ImageView icon(Context c, int res, int color, int padDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(color);
        int p = dp(c, padDp);
        v.setPadding(p, p, p, p);
        return v;
    }

    public static ImageView iconBtn(Context c, int res, String desc) {
        ImageView v = icon(c, res, T.tx, 11);
        v.setContentDescription(desc);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)));
        return v;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(T.bd);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        return v;
    }

    public static TextView pill(Context c, String s, boolean on) {
        TextView t = text(c, s, 13, on ? T.ac : T.mu, true);
        t.setBackground(shape(c, on ? T.tn : T.ib, 20, 0));
        t.setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8));
        t.setSingleLine(true);
        return t;
    }

    public static TextView button(Context c, String s, boolean primary) {
        TextView t = text(c, s, 14, primary ? Color.WHITE : T.tx, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(c, primary ? T.ac : T.ib, 8, 0));
        t.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        return t;
    }

    public static AlertDialog.Builder dlg(Context c) {
        return new AlertDialog.Builder(c, T.dark
                ? android.R.style.Theme_Material_Dialog_Alert
                : android.R.style.Theme_Material_Light_Dialog_Alert);
    }

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    public static void toastLong(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_LONG).show();
    }

    public static EditText field(Context c, String hint, String initial, boolean password) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(initial);
        e.setSingleLine(true);
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    public static LinearLayout box(Context c, View... views) {
        LinearLayout b = new LinearLayout(c);
        b.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 20);
        b.setPadding(p, dp(c, 8), p, 0);
        for (View v : views) b.addView(v, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return b;
    }

    public static void prompt(Context c, String title, String hint, String initial, final Cb<String> ok) {
        final EditText e = field(c, hint, initial, false);
        dlg(c).setTitle(title).setView(box(c, e))
                .setPositiveButton("OK", (d, w) -> ok.done(e.getText().toString().trim()))
                .setNegativeButton("Cancel", null).show();
    }

    public static void confirm(Context c, String msg, String yes, final Runnable r) {
        dlg(c).setMessage(msg).setPositiveButton(yes, (d, w) -> r.run())
                .setNegativeButton("Cancel", null).show();
    }

    public static Dialog sheet(Activity a, View content, int heightDp) {
        Dialog d = new Dialog(a, T.dark
                ? android.R.style.Theme_Material_Dialog_NoActionBar
                : android.R.style.Theme_Material_Light_Dialog_NoActionBar);
        d.setContentView(content);
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(T.sf));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, heightDp));
            w.setGravity(Gravity.BOTTOM);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        return d;
    }
}
